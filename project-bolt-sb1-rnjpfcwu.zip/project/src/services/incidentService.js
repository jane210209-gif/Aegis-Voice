import api from './api'

export async function getIncidents() {
  const res = await api.get('/api/incidents')
  return res.data
}
