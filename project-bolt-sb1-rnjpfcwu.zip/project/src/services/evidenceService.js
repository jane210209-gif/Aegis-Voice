import api from './api'

export async function getEvidence() {
  const res = await api.get('/api/evidence')
  return res.data
}

export async function saveEvidence(payload) {
  const res = await api.post('/api/evidence', payload)
  return res.data
}

export async function deleteEvidence(id) {
  const res = await api.delete('/api/evidence', { data: { id } })
  return res.data
}
