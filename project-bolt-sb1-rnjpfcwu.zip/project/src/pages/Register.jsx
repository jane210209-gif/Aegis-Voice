import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import toast from 'react-hot-toast'
import { Shield, Eye, EyeOff, Check } from 'lucide-react'
import { useAuth } from '../context/AuthContext'

export default function Register() {
  const { register, loading } = useAuth()
  const navigate = useNavigate()
  const [form, setForm] = useState({ name: '', email: '', password: '', confirmPassword: '', consent: false })
  const [showPass, setShowPass] = useState(false)
  const [errors, setErrors] = useState({})

  const validate = () => {
    const e = {}
    if (!form.name.trim()) e.name = 'Name is required.'
    if (!form.email.trim()) e.email = 'Email is required.'
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'Enter a valid email address.'
    if (!form.password) e.password = 'Password is required.'
    else if (form.password.length < 8) e.password = 'Password must be at least 8 characters.'
    if (form.confirmPassword !== form.password) e.confirmPassword = 'Passwords do not match.'
    if (!form.consent) e.consent = 'Please acknowledge the privacy notice to continue.'
    setErrors(e)
    return Object.keys(e).length === 0
  }

  const handleSubmit = async (ev) => {
    ev.preventDefault()
    if (!validate()) return
    try {
      await register({ name: form.name, email: form.email, password: form.password })
      toast.success('Account created. Welcome to Aegis Voice.')
      navigate('/dashboard')
    } catch (err) {
      const msg = err?.response?.data?.detail || err?.response?.data?.message || 'Could not create your account. Please try again.'
      toast.error(msg)
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-bglight px-4 py-8 dark:bg-navy-800">
      <div className="w-full max-w-md">
        <Link to="/" className="mb-8 flex items-center justify-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-electric text-white">
            <Shield className="h-5 w-5" />
          </div>
          <span className="text-lg font-bold text-navy-700 dark:text-navy-50">Aegis Voice</span>
        </Link>

        <div className="card p-8">
          <h1 className="text-2xl font-bold text-navy-700 dark:text-navy-50">Create your account</h1>
          <p className="mt-2 text-sm text-navy-400 dark:text-navy-200">
            Your data stays yours. We only analyse what you submit.
          </p>

          <form onSubmit={handleSubmit} className="mt-6 space-y-4">
            <div>
              <label className="label" htmlFor="name">Name</label>
              <input
                id="name"
                type="text"
                className="input"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="Your name"
                autoComplete="name"
              />
              {errors.name && <p className="mt-1 text-xs text-danger">{errors.name}</p>}
            </div>

            <div>
              <label className="label" htmlFor="email">Email</label>
              <input
                id="email"
                type="email"
                className="input"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                placeholder="you@example.com"
                autoComplete="email"
              />
              {errors.email && <p className="mt-1 text-xs text-danger">{errors.email}</p>}
            </div>

            <div>
              <label className="label" htmlFor="password">Password</label>
              <div className="relative">
                <input
                  id="password"
                  type={showPass ? 'text' : 'password'}
                  className="input pr-10"
                  value={form.password}
                  onChange={(e) => setForm({ ...form, password: e.target.value })}
                  placeholder="At least 8 characters"
                  autoComplete="new-password"
                />
                <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-3 top-1/2 -translate-y-1/2 text-navy-300 hover:text-navy-500">
                  {showPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              {errors.password && <p className="mt-1 text-xs text-danger">{errors.password}</p>}
            </div>

            <div>
              <label className="label" htmlFor="confirmPassword">Confirm password</label>
              <input
                id="confirmPassword"
                type={showPass ? 'text' : 'password'}
                className="input"
                value={form.confirmPassword}
                onChange={(e) => setForm({ ...form, confirmPassword: e.target.value })}
                placeholder="Re-enter your password"
                autoComplete="new-password"
              />
              {errors.confirmPassword && <p className="mt-1 text-xs text-danger">{errors.confirmPassword}</p>}
            </div>

            <label className="flex cursor-pointer items-start gap-3 rounded-xl bg-navy-50 p-4 dark:bg-navy-600">
              <button
                type="button"
                onClick={() => setForm({ ...form, consent: !form.consent })}
                className={`mt-0.5 flex h-5 w-5 shrink-0 items-center justify-center rounded-md border transition-colors ${
                  form.consent ? 'border-electric bg-electric text-white' : 'border-navy-200 dark:border-navy-500'
                }`}
              >
                {form.consent && <Check className="h-3.5 w-3.5" />}
              </button>
              <span className="text-sm text-navy-400 dark:text-navy-200">
                I understand Aegis Voice will only analyse files and text I submit, and that scores are model estimates, not proof.
              </span>
            </label>
            {errors.consent && <p className="-mt-2 text-xs text-danger">{errors.consent}</p>}

            <button type="submit" disabled={loading} className="btn-primary w-full">
              {loading ? 'Creating account…' : 'Create account'}
            </button>
          </form>

          <p className="mt-6 text-center text-sm text-navy-400 dark:text-navy-200">
            Already have an account?{' '}
            <Link to="/login" className="font-medium text-electric hover:underline">Log in</Link>
          </p>
        </div>
      </div>
    </div>
  )
}
