import { AlertTriangle, WifiOff, FileQuestion } from 'lucide-react'
import { isNetworkError, isNotFound } from '../utils/helpers'

export function ErrorState({ error, title, onRetry }) {
  let icon = <AlertTriangle className="h-6 w-6 text-danger" />
  let headline = title || 'Something went wrong'
  let detail = error?.message || 'We could not complete this action.'

  if (isNetworkError(error)) {
    icon = <WifiOff className="h-6 w-6 text-warning" />
    headline = "Can't reach Aegis Voice right now"
    detail = 'Check your connection or try again in a moment.'
  } else if (isNotFound(error)) {
    icon = <FileQuestion className="h-6 w-6 text-navy-300" />
    headline = "This action isn't available yet"
    detail = 'This feature has not been connected to the server yet.'
  }

  return (
    <div className="card flex flex-col items-center gap-3 p-8 text-center">
      <div className="rounded-full bg-danger/10 p-3 dark:bg-danger/20">{icon}</div>
      <h3 className="text-lg font-semibold text-navy-700 dark:text-navy-50">{headline}</h3>
      <p className="max-w-md text-sm text-navy-400 dark:text-navy-200">{detail}</p>
      {onRetry && (
        <button onClick={onRetry} className="btn-secondary mt-2">
          Try again
        </button>
      )}
    </div>
  )
}

export function EmptyState({ title, message, icon: Icon, action }) {
  return (
    <div className="card flex flex-col items-center gap-3 p-8 text-center">
      {Icon && (
        <div className="rounded-full bg-navy-50 p-3 dark:bg-navy-500">
          <Icon className="h-6 w-6 text-navy-300 dark:text-navy-100" />
        </div>
      )}
      <h3 className="text-lg font-semibold text-navy-700 dark:text-navy-50">{title}</h3>
      {message && <p className="max-w-md text-sm text-navy-400 dark:text-navy-200">{message}</p>}
      {action}
    </div>
  )
}

export function SkeletonCard({ lines = 3 }) {
  return (
    <div className="card p-5">
      <div className="skeleton mb-4 h-4 w-1/3" />
      {Array.from({ length: lines }).map((_, i) => (
        <div key={i} className="skeleton mb-3 h-3" style={{ width: `${100 - i * 12}%` }} />
      ))}
    </div>
  )
}

export function SkeletonRows({ count = 4 }) {
  return (
    <div className="space-y-3">
      {Array.from({ length: count }).map((_, i) => (
        <div key={i} className="card flex items-center gap-4 p-4">
          <div className="skeleton h-10 w-10 rounded-full" />
          <div className="flex-1 space-y-2">
            <div className="skeleton h-3 w-1/2" />
            <div className="skeleton h-3 w-1/4" />
          </div>
        </div>
      ))}
    </div>
  )
}
