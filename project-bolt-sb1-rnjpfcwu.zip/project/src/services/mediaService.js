import api from './api'

export async function uploadMedia(file, onProgress) {
  const form = new FormData()
  form.append('file', file)
  const res = await api.post('/api/media/', form, {
    headers: { 'Content-Type': 'multipart/form-data' },
    onUploadProgress: (e) => {
      if (onProgress && e.total) onProgress(Math.round((e.loaded * 100) / e.total))
    },
  })
  return res.data
}

export async function getMedia() {
  const res = await api.get('/api/media/')
  return res.data
}
