import { useEffect, useState } from 'react'
import toast from 'react-hot-toast'
import {
  Instagram, Facebook, Youtube, Twitter, MessageCircle, Share2,
  Link2, Link2Off, Clock, CheckCircle2, AlertCircle, RefreshCw,
} from 'lucide-react'
import { PageHeader } from '../components/Shared'
import { ErrorState, SkeletonCard } from '../components/StateViews'
import { ConfirmDialog } from '../components/Modal'
import { getSocial, connectSocial, disconnectSocial } from '../services/socialService'
import { ensureArray, formatDate, classNames } from '../utils/helpers'

const PLATFORM_META = {
  instagram: { name: 'Instagram', icon: Instagram, color: 'text-pink-500' },
  facebook: { name: 'Facebook', icon: Facebook, color: 'text-blue-600' },
  youtube: { name: 'YouTube', icon: Youtube, color: 'text-red-500' },
  x: { name: 'X (Twitter)', icon: Twitter, color: 'text-navy-700 dark:text-navy-50' },
  reddit: { name: 'Reddit', icon: MessageCircle, color: 'text-orange-500' },
}

function normalize(item) {
  const platform = item?.platform || item?.name || ''
  const key = String(platform).toLowerCase()
  return {
    platform,
    key,
    connected: item?.connected === true || item?.status === 'connected',
    capabilities: ensureArray(item?.capabilities),
    lastSync: item?.last_sync || item?.last_synced || item?.updated_at,
    raw: item,
  }
}

export default function SocialMonitoring() {
  const [platforms, setPlatforms] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [connecting, setConnecting] = useState(null)
  const [confirmDisconnect, setConfirmDisconnect] = useState(null)

  const load = async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await getSocial()
      const arr = ensureArray(res)
      // Merge known platforms with API data
      const fromApi = arr.map(normalize)
      const knownKeys = fromApi.map((p) => p.key)
      const missing = Object.entries(PLATFORM_META)
        .filter(([k]) => !knownKeys.includes(k))
        .map(([key, meta]) => ({
          platform: meta.name,
          key,
          connected: false,
          capabilities: [],
          lastSync: null,
        }))
      setPlatforms([...fromApi, ...missing])
    } catch (err) {
      setError(err)
      // Still show disconnected cards
      const fallback = Object.entries(PLATFORM_META).map(([key, meta]) => ({
        platform: meta.name,
        key,
        connected: false,
        capabilities: [],
        lastSync: null,
      }))
      setPlatforms(fallback)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  const handleConnect = async (platformKey) => {
    setConnecting(platformKey)
    try {
      await connectSocial(platformKey)
      toast.success(`${PLATFORM_META[platformKey]?.name || platformKey} connected.`)
      load()
    } catch (err) {
      const status = err?.response?.status
      if (status === 404) {
        toast.error("This action isn't available yet.")
      } else {
        toast.error(err?.response?.data?.detail || 'Could not connect. Please try again.')
      }
    } finally {
      setConnecting(null)
    }
  }

  const handleDisconnect = async (platformKey) => {
    try {
      await disconnectSocial(platformKey)
      toast.success(`${PLATFORM_META[platformKey]?.name || platformKey} disconnected.`)
      load()
    } catch (err) {
      const status = err?.response?.status
      if (status === 404) {
        toast.error("This action isn't available yet.")
      } else {
        toast.error('Could not disconnect. Please try again.')
      }
    }
  }

  if (loading) {
    return (
      <div>
        <PageHeader title="Social Monitoring" description="Connect platforms to monitor for misuse. Cards stay disconnected until the backend confirms." />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 5 }).map((_, i) => <SkeletonCard key={i} />)}
        </div>
      </div>
    )
  }

  return (
    <div>
      <PageHeader
        title="Social Monitoring"
        description="Connect platforms to monitor for misuse. Cards stay “Not connected” until the backend confirms."
        action={<button onClick={load} className="btn-secondary"><RefreshCw className="h-4 w-4" /> Refresh</button>}
      />

      {error && !loading && (
        <div className="mb-6">
          <ErrorState error={error} />
        </div>
      )}

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {platforms.map((p) => {
          const meta = PLATFORM_META[p.key] || { name: p.platform, icon: Share2, color: 'text-navy-500' }
          const Icon = meta.icon
          return (
            <div key={p.key} className="card p-6">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="rounded-xl bg-navy-50 p-3 dark:bg-navy-600">
                    <Icon className={classNames('h-6 w-6', meta.color)} />
                  </div>
                  <div>
                    <h3 className="font-semibold text-navy-600 dark:text-navy-50">{meta.name}</h3>
                    <p className="text-xs text-navy-400 dark:text-navy-200">
                      {p.connected ? 'Connected' : 'Not connected'}
                    </p>
                  </div>
                </div>
                {p.connected ? (
                  <span className="badge bg-safe/15 text-safe">
                    <CheckCircle2 className="h-3 w-3" /> Active
                  </span>
                ) : (
                  <span className="badge bg-navy-100 text-navy-400 dark:bg-navy-500 dark:text-navy-200">
                    <AlertCircle className="h-3 w-3" /> Inactive
                  </span>
                )}
              </div>

              {/* Capabilities */}
              {p.capabilities.length > 0 && (
                <div className="mt-4">
                  <p className="text-xs font-medium text-navy-400 dark:text-navy-200">Capabilities</p>
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {p.capabilities.map((c, i) => (
                      <span key={i} className="badge bg-navy-100 text-navy-500 dark:bg-navy-500 dark:text-navy-100">
                        {typeof c === 'string' ? c : c?.label || 'capability'}
                      </span>
                    ))}
                  </div>
                </div>
              )}

              {/* Last sync */}
              {p.connected && (
                <div className="mt-4 flex items-center gap-2 text-xs text-navy-300 dark:text-navy-300">
                  <Clock className="h-3.5 w-3.5" />
                  Last sync: {formatDate(p.lastSync)}
                </div>
              )}

              {/* Actions */}
              <div className="mt-5">
                {p.connected ? (
                  <button
                    onClick={() => setConfirmDisconnect(p.key)}
                    className="btn-secondary w-full"
                  >
                    <Link2Off className="h-4 w-4" /> Disconnect
                  </button>
                ) : (
                  <button
                    onClick={() => handleConnect(p.key)}
                    disabled={connecting === p.key}
                    className="btn-primary w-full"
                  >
                    <Link2 className="h-4 w-4" />
                    {connecting === p.key ? 'Connecting…' : 'Connect'}
                  </button>
                )}
              </div>
            </div>
          )
        })}
      </div>

      <div className="card mt-6 flex items-start gap-3 p-5">
        <AlertCircle className="h-5 w-5 shrink-0 text-warning" />
        <p className="text-sm text-navy-400 dark:text-navy-200">
          Aegis Voice does not scan WhatsApp or Signal. Connected platforms are monitored only for publicly visible misuse.
          A platform never shows as “connected” unless the backend confirms it.
        </p>
      </div>

      <ConfirmDialog
        open={!!confirmDisconnect}
        onClose={() => setConfirmDisconnect(null)}
        onConfirm={() => handleDisconnect(confirmDisconnect)}
        title="Disconnect this platform?"
        message="You'll stop receiving alerts from this platform until you reconnect."
        confirmLabel="Disconnect"
        danger
      />
    </div>
  )
}
