/** @type {import('tailwindcss').Config} */
export default {
  darkMode: 'class',
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        navy: {
          DEFAULT: '#0A1628',
          50: '#E6EAF0',
          100: '#C1CAD9',
          200: '#92A2BD',
          300: '#647AA0',
          400: '#3B5480',
          500: '#1E3258',
          600: '#0F1F3D',
          700: '#0A1628',
          800: '#07101F',
          900: '#040A15',
        },
        electric: '#2563EB',
        cyan: '#06B6D4',
        safe: '#10B981',
        warning: '#F59E0B',
        danger: '#EF4444',
        bglight: '#F8FAFC',
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'Avenir', 'Helvetica', 'Arial', 'sans-serif'],
      },
      boxShadow: {
        card: '0 1px 3px rgba(10,22,40,0.08), 0 4px 12px rgba(10,22,40,0.06)',
        cardlg: '0 4px 16px rgba(10,22,40,0.10), 0 12px 32px rgba(10,22,40,0.08)',
      },
      borderRadius: {
        xl2: '1.25rem',
      },
      keyframes: {
        fadeIn: {
          '0%': { opacity: '0', transform: 'translateY(4px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' },
        },
        pulseSoft: {
          '0%, 100%': { opacity: '1' },
          '50%': { opacity: '0.55' },
        },
      },
      animation: {
        fadeIn: 'fadeIn 0.3s ease-out',
        pulseSoft: 'pulseSoft 1.8s ease-in-out infinite',
      },
    },
  },
  plugins: [],
}
