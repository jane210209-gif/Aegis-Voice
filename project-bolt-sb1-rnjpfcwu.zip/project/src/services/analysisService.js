import api from './api'

export async function analyzeImage(payload) {
  const res = await api.post('/api/analysis/image', payload)
  return res.data
}

export async function analyzeVideo(payload) {
  const res = await api.post('/api/analysis/video', payload)
  return res.data
}

export async function analyzeDeepfake(payload) {
  const res = await api.post('/api/analysis/deepfake', payload)
  return res.data
}

export async function analyzeHarassment(payload) {
  const res = await api.post('/api/analysis/harassment', payload)
  return res.data
}
