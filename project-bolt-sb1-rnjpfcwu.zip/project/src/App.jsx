import { Routes, Route } from 'react-router-dom'
import { Toaster } from 'react-hot-toast'
import { AuthProvider } from './context/AuthContext'
import { ThemeProvider } from './context/ThemeContext'
import AppLayout from './layouts/AppLayout'
import ProtectedRoute from './layouts/ProtectedRoute'
import Landing from './pages/Landing'
import Register from './pages/Register'
import Login from './pages/Login'
import Dashboard from './pages/Dashboard'
import MediaUpload from './pages/MediaUpload'
import ImageResult from './pages/ImageResult'
import VideoAnalysis from './pages/VideoAnalysis'
import DeepfakeResult from './pages/DeepfakeResult'
import HarassmentText from './pages/HarassmentText'
import SocialMonitoring from './pages/SocialMonitoring'
import Alerts from './pages/Alerts'
import EvidenceVault from './pages/EvidenceVault'
import SOS from './pages/SOS'
import Settings from './pages/Settings'

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/register" element={<Register />} />
          <Route path="/login" element={<Login />} />
          <Route
            element={
              <ProtectedRoute>
                <AppLayout />
              </ProtectedRoute>
            }
          >
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/media" element={<MediaUpload />} />
            <Route path="/analysis/image" element={<ImageResult />} />
            <Route path="/analysis/video" element={<VideoAnalysis />} />
            <Route path="/analysis/deepfake" element={<DeepfakeResult />} />
            <Route path="/analysis/harassment" element={<HarassmentText />} />
            <Route path="/social" element={<SocialMonitoring />} />
            <Route path="/alerts" element={<Alerts />} />
            <Route path="/evidence" element={<EvidenceVault />} />
            <Route path="/sos" element={<SOS />} />
            <Route path="/settings" element={<Settings />} />
          </Route>
        </Routes>
        <Toaster
          position="top-right"
          toastOptions={{
            duration: 4000,
            style: {
              background: '#0A1628',
              color: '#F8FAFC',
              borderRadius: '12px',
              fontSize: '14px',
            },
          }}
        />
      </AuthProvider>
    </ThemeProvider>
  )
}
