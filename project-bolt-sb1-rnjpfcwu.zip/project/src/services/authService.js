import api from './api'

function parseUser(data) {
  return {
    id: data?.id ?? data?.user_id ?? null,
    name: data?.name ?? data?.user?.name ?? '',
    email: data?.email ?? data?.user?.email ?? '',
  }
}

export async function register(payload) {
  const res = await api.post('/api/auth/register', payload)
  if (res.data?.token) localStorage.setItem('aegis_token', res.data.token)
  if (res.data?.user || res.data?.id) localStorage.setItem('aegis_user', JSON.stringify(parseUser(res.data)))
  return { token: res.data?.token ?? null, user: parseUser(res.data) }
}

export async function login(payload) {
  const res = await api.post('/api/auth/login', payload)
  if (res.data?.token) localStorage.setItem('aegis_token', res.data.token)
  if (res.data?.user || res.data?.id) localStorage.setItem('aegis_user', JSON.stringify(parseUser(res.data)))
  return { token: res.data?.token ?? null, user: parseUser(res.data) }
}

export async function logout() {
  try {
    await api.post('/api/auth/logout')
  } catch {
    /* best-effort */
  } finally {
    localStorage.removeItem('aegis_token')
    localStorage.removeItem('aegis_user')
  }
}
