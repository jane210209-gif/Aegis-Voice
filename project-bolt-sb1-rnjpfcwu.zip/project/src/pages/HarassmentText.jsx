import { useState } from 'react'
import toast from 'react-hot-toast'
import { MessageSquareWarning, Save, X, Info, Globe, Sparkles } from 'lucide-react'
import { PageHeader, RiskBadge } from '../components/Shared'
import { ConfirmDialog } from '../components/Modal'
import { analyzeHarassment } from '../services/analysisService'
import { saveEvidence } from '../services/evidenceService'
import { ensureArray, pickNumber } from '../utils/helpers'

const LANGUAGES = [
  { value: 'auto', label: 'Auto-detect' },
  { value: 'en', label: 'English' },
  { value: 'hi', label: 'हिन्दी (Hindi)' },
  { value: 'te', label: 'తెలుగు (Telugu)' },
  { value: 'ta', label: 'தமிழ் (Tamil)' },
  { value: 'code-mixed', label: 'Code-mixed (Hinglish/Tanglish)' },
]

export default function HarassmentText() {
  const [text, setText] = useState('')
  const [language, setLanguage] = useState('auto')
  const [analyzing, setAnalyzing] = useState(false)
  const [result, setResult] = useState(null)
  const [error, setError] = useState(null)
  const [confirmSave, setConfirmSave] = useState(false)

  const handleAnalyze = async () => {
    if (!text.trim()) {
      toast.error('Please paste some text to analyse.')
      return
    }
    setAnalyzing(true)
    setError(null)
    setResult(null)
    try {
      const res = await analyzeHarassment({ text, language })
      setResult(res)
    } catch (err) {
      const status = err?.response?.status
      if (status === 404) {
        setError('This action isn\'t available yet.')
      } else {
        setError(err?.response?.data?.detail || err?.response?.data?.message || 'Analysis failed. Please try again.')
      }
    } finally {
      setAnalyzing(false)
    }
  }

  const handleSave = async () => {
    try {
      await saveEvidence({
        type: 'harassment',
        description: `Harassment analysis — ${result?.language || language}`,
        data: { text, ...result },
      })
      toast.success('Saved to your evidence vault.')
    } catch {
      toast.error('Could not save evidence. Please try again.')
    }
  }

  const categories = ensureArray(result?.categories || result?.category)
  const confidence = pickNumber(result?.confidence ?? result?.score, 0)

  return (
    <div>
      <PageHeader
        title="Harassment Text Detection"
        description="Detect abuse in English, Hindi, Telugu, Tamil, and code-mixed text. Results are model estimates."
      />

      <div className="card p-6">
        <div className="mb-2 flex items-start gap-2 rounded-xl bg-safe/10 p-3 text-xs text-safe">
          <Info className="h-4 w-4 shrink-0" />
          <span>Devanagari, Telugu, and Tamil scripts are fully supported. Paste any text — including Hinglish or Tanglish.</span>
        </div>

        {/* Language selector */}
        <div className="mb-4">
          <label className="label" htmlFor="lang">Language</label>
          <div className="relative">
            <Globe className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-navy-300" />
            <select
              id="lang"
              value={language}
              onChange={(e) => setLanguage(e.target.value)}
              className="input pl-10"
            >
              {LANGUAGES.map((l) => (
                <option key={l.value} value={l.value}>{l.label}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Text area */}
        <div>
          <label className="label" htmlFor="text">Text to analyse</label>
          <textarea
            id="text"
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Paste the message, comment, or post you'd like to check…"
            rows={6}
            className="input resize-y"
          />
        </div>

        <p className="mt-2 text-xs text-navy-300 dark:text-navy-300">
          {text.length} characters
        </p>

        <button onClick={handleAnalyze} disabled={!text.trim() || analyzing} className="btn-primary mt-4 w-full">
          <MessageSquareWarning className="h-4 w-4" />
          {analyzing ? 'Analysing text…' : 'Analyse text'}
        </button>
      </div>

      {/* Loading */}
      {analyzing && (
        <div className="card mt-6 p-8 text-center">
          <div className="mx-auto h-10 w-10 animate-pulseSoft rounded-full bg-electric/10" />
          <p className="mt-3 text-sm text-navy-400 dark:text-navy-200">
            Detecting harassment patterns…
          </p>
        </div>
      )}

      {/* Error */}
      {error && !analyzing && (
        <div className="card mt-6 flex items-start gap-3 p-5">
          <X className="h-5 w-5 shrink-0 text-danger" />
          <p className="text-sm text-danger">{error}</p>
        </div>
      )}

      {/* Result */}
      {result && !analyzing && (
        <div className="mt-6 space-y-6">
          <div className="card p-6">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="flex items-center gap-2 font-semibold text-navy-600 dark:text-navy-50">
                  <Sparkles className="h-5 w-5 text-electric" />
                  Detection Result
                </h3>
                <p className="mt-2 text-sm text-navy-400 dark:text-navy-200">
                  {result?.explanation || result?.message || 'Analysis complete.'}
                </p>
              </div>
              <RiskBadge level={result?.risk || result?.level} />
            </div>

            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <div className="rounded-xl bg-navy-50 p-4 dark:bg-navy-600">
                <p className="text-xs text-navy-400 dark:text-navy-200">Detected language</p>
                <p className="mt-1 text-sm font-medium text-navy-700 dark:text-navy-50">
                  {result?.language || result?.detected_language || '—'}
                </p>
              </div>
              <div className="rounded-xl bg-navy-50 p-4 dark:bg-navy-600">
                <p className="text-xs text-navy-400 dark:text-navy-200">Confidence (model estimate)</p>
                <p className="mt-1 text-xl font-bold text-navy-700 dark:text-navy-50">
                  {confidence > 0 ? `${(confidence * 100).toFixed(1)}%` : '—'}
                </p>
              </div>
            </div>

            {/* Categories */}
            {categories.length > 0 && (
              <div className="mt-4">
                <p className="label">Categories detected</p>
                <div className="flex flex-wrap gap-2">
                  {categories.map((c, i) => {
                    const label = typeof c === 'string' ? c : c?.label ?? c?.name ?? 'unknown'
                    const sev = typeof c === 'object' ? c?.severity : null
                    return (
                      <span key={i} className="badge bg-danger/10 text-danger">
                        {label}
                        {sev && <span className="opacity-70">· {sev}</span>}
                      </span>
                    )
                  })}
                </div>
              </div>
            )}

            <div className="mt-4 flex items-start gap-2 rounded-xl bg-warning/10 p-3 text-xs text-warning">
              <Info className="h-4 w-4 shrink-0" />
              <span>This is a model estimate, not proof. Context matters — some phrases may be flagged incorrectly.</span>
            </div>

            <div className="mt-4">
              <button onClick={() => setConfirmSave(true)} className="btn-primary">
                <Save className="h-4 w-4" /> Save as evidence
              </button>
            </div>
          </div>
        </div>
      )}

      <ConfirmDialog
        open={confirmSave}
        onClose={() => setConfirmSave(false)}
        onConfirm={handleSave}
        title="Save to evidence vault?"
        message="The text and its analysis will be saved to your private evidence vault."
        confirmLabel="Save"
      />
    </div>
  )
}
