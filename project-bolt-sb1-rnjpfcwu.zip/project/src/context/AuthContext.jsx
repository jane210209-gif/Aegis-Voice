import { createContext, useContext, useState, useCallback, useEffect } from 'react'
import { register as registerReq, login as loginReq, logout as logoutReq } from '../services/authService'

const AuthContext = createContext(null)

export function AuthProvider({ children }) {
  const [token, setToken] = useState(() => localStorage.getItem('aegis_token'))
  const [user, setUser] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem('aegis_user') || 'null')
    } catch {
      return null
    }
  })
  const [loading, setLoading] = useState(false)

  useEffect(() => {
    const handler = () => {
      setToken(localStorage.getItem('aegis_token'))
      setUser(() => {
        try {
          return JSON.parse(localStorage.getItem('aegis_user') || 'null')
        } catch {
          return null
        }
      })
    }
    window.addEventListener('aegis:auth-change', handler)
    return () => window.removeEventListener('aegis:auth-change', handler)
  }, [])

  const login = useCallback(async (payload) => {
    setLoading(true)
    try {
      const data = await loginReq(payload)
      setToken(data.token)
      setUser(data.user)
      window.dispatchEvent(new Event('aegis:auth-change'))
      return data
    } finally {
      setLoading(false)
    }
  }, [])

  const register = useCallback(async (payload) => {
    setLoading(true)
    try {
      const data = await registerReq(payload)
      setToken(data.token)
      setUser(data.user)
      window.dispatchEvent(new Event('aegis:auth-change'))
      return data
    } finally {
      setLoading(false)
    }
  }, [])

  const logout = useCallback(async () => {
    await logoutReq()
    setToken(null)
    setUser(null)
    window.dispatchEvent(new Event('aegis:auth-change'))
  }, [])

  return (
    <AuthContext.Provider value={{ token, user, loading, login, register, logout, isAuthenticated: !!token }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const ctx = useContext(AuthContext)
  if (!ctx) throw new Error('useAuth must be used within AuthProvider')
  return ctx
}
