import { useState } from 'react'
import toast from 'react-hot-toast'
import { ScanSearch, ShieldAlert, ExternalLink, Save, X, Info } from 'lucide-react'
import { PageHeader, RiskBadge } from '../components/Shared'
import { Dropzone } from '../components/Dropzone'
import { ConfirmDialog } from '../components/Modal'
import { analyzeImage } from '../services/analysisService'
import { saveEvidence } from '../services/evidenceService'
import { ensureArray, pickNumber } from '../utils/helpers'

export default function ImageResult() {
  const [file, setFile] = useState(null)
  const [previewUrl, setPreviewUrl] = useState(null)
  const [analyzing, setAnalyzing] = useState(false)
  const [result, setResult] = useState(null)
  const [error, setError] = useState(null)
  const [confirmSave, setConfirmSave] = useState(false)
  const [flagWrong, setFlagWrong] = useState(false)

  const handleFile = (f) => {
    setFile(f)
    setResult(null)
    setError(null)
    setPreviewUrl(URL.createObjectURL(f))
  }

  const handleAnalyze = async () => {
    if (!file) return
    setAnalyzing(true)
    setError(null)
    setResult(null)
    try {
      const formData = new FormData()
      formData.append('file', file)
      const res = await analyzeImage(formData)
      setResult(res)
    } catch (err) {
      const status = err?.response?.status
      if (status === 404) {
        setError('This action isn\'t available yet.')
      } else {
        setError(err?.response?.data?.detail || err?.response?.data?.message || 'Analysis failed. Please try again.')
      }
    } finally {
      setAnalyzing(false)
    }
  }

  const handleSave = async () => {
    try {
      await saveEvidence({
        type: 'image',
        source_url: result?.source_url || '',
        description: result?.explanation || 'Image misuse analysis result',
        data: result,
      })
      toast.success('Saved to your evidence vault.')
    } catch {
      toast.error('Could not save evidence. Please try again.')
    }
  }

  const handleFlagWrong = () => {
    setFlagWrong(true)
    toast.success('Thank you. Your feedback helps us improve our estimates.')
  }

  const matches = ensureArray(result?.matches || result?.results)
  const similarity = pickNumber(result?.similarity ?? result?.confidence, 0)

  return (
    <div>
      <PageHeader
        title="Image Misuse Detection"
        description="Check if your image has been misused. Results are model estimates — not proof."
      />

      <div className="card p-6">
        <Dropzone accept="image" onFile={handleFile} disabled={analyzing} />

        {previewUrl && (
          <div className="mt-4">
            <p className="label">Preview</p>
            <img src={previewUrl} alt="Selected" className="max-h-64 rounded-xl object-contain" />
          </div>
        )}

        <button onClick={handleAnalyze} disabled={!file || analyzing} className="btn-primary mt-6 w-full">
          <ScanSearch className="h-4 w-4" />
          {analyzing ? 'Analysing…' : 'Analyse image'}
        </button>
      </div>

      {/* Loading */}
      {analyzing && (
        <div className="card mt-6 p-8 text-center">
          <div className="mx-auto h-10 w-10 animate-pulseSoft rounded-full bg-electric/10" />
          <p className="mt-3 text-sm text-navy-400 dark:text-navy-200">
            Running analysis. This can take a moment…
          </p>
        </div>
      )}

      {/* Error */}
      {error && !analyzing && (
        <div className="card mt-6 flex items-start gap-3 p-5">
          <X className="h-5 w-5 shrink-0 text-danger" />
          <p className="text-sm text-danger">{error}</p>
        </div>
      )}

      {/* Result */}
      {result && !analyzing && (
        <div className="mt-6 space-y-6">
          {/* Summary */}
          <div className="card p-6">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="flex items-center gap-2 font-semibold text-navy-600 dark:text-navy-50">
                  <ShieldAlert className="h-5 w-5 text-warning" />
                  Analysis Result
                </h3>
                <p className="mt-2 text-sm text-navy-400 dark:text-navy-200">
                  {result?.explanation || result?.message || 'Analysis complete. See details below.'}
                </p>
              </div>
              <RiskBadge level={result?.risk || result?.level} />
            </div>

            <div className="mt-4 grid gap-4 sm:grid-cols-3">
              <div className="rounded-xl bg-navy-50 p-4 dark:bg-navy-600">
                <p className="text-xs text-navy-400 dark:text-navy-200">Estimated similarity</p>
                <p className="mt-1 text-xl font-bold text-navy-700 dark:text-navy-50">
                  {similarity > 0 ? `${(similarity * 100).toFixed(1)}%` : '—'}
                </p>
              </div>
              <div className="rounded-xl bg-navy-50 p-4 dark:bg-navy-600">
                <p className="text-xs text-navy-400 dark:text-navy-200">Platform</p>
                <p className="mt-1 text-sm font-medium text-navy-700 dark:text-navy-50">{result?.platform || '—'}</p>
              </div>
              <div className="rounded-xl bg-navy-50 p-4 dark:bg-navy-600">
                <p className="text-xs text-navy-400 dark:text-navy-200">Source URL</p>
                {result?.source_url ? (
                  <a href={result.source_url} target="_blank" rel="noopener noreferrer" className="mt-1 flex items-center gap-1 text-sm font-medium text-electric hover:underline">
                    View source <ExternalLink className="h-3 w-3" />
                  </a>
                ) : (
                  <p className="mt-1 text-sm text-navy-400 dark:text-navy-200">—</p>
                )}
              </div>
            </div>

            <div className="mt-4 flex items-start gap-2 rounded-xl bg-warning/10 p-3 text-xs text-warning">
              <Info className="h-4 w-4 shrink-0" />
              <span>This is a model estimate, not proof. If this result looks wrong, please let us know.</span>
            </div>

            <div className="mt-4 flex gap-3">
              <button onClick={() => setConfirmSave(true)} className="btn-primary">
                <Save className="h-4 w-4" /> Save evidence
              </button>
              <button onClick={handleFlagWrong} disabled={flagWrong} className="btn-secondary">
                <X className="h-4 w-4" /> {flagWrong ? 'Flagged' : 'This looks wrong'}
              </button>
            </div>
          </div>

          {/* Matches */}
          {matches.length > 0 && (
            <div className="card p-6">
              <h3 className="font-semibold text-navy-600 dark:text-navy-50">Potential matches ({matches.length})</h3>
              <div className="mt-4 grid gap-4 sm:grid-cols-2">
                {matches.map((m, i) => (
                  <div key={i} className="rounded-xl border border-navy-100 p-4 dark:border-navy-500">
                    {m?.thumbnail || m?.url ? (
                      <img src={m.thumbnail || m.url} alt="match" className="mb-3 h-32 w-full rounded-lg object-cover" />
                    ) : (
                      <div className="mb-3 h-32 w-full rounded-lg bg-navy-100 dark:bg-navy-500" />
                    )}
                    <p className="text-sm font-medium text-navy-600 dark:text-navy-50">{m?.platform || m?.source || 'Unknown source'}</p>
                    {m?.similarity != null && (
                      <p className="text-xs text-navy-400 dark:text-navy-200">Similarity: {(pickNumber(m.similarity) * 100).toFixed(1)}%</p>
                    )}
                    {m?.url && (
                      <a href={m.url} target="_blank" rel="noopener noreferrer" className="mt-1 flex items-center gap-1 text-xs text-electric hover:underline">
                        View <ExternalLink className="h-3 w-3" />
                      </a>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      <ConfirmDialog
        open={confirmSave}
        onClose={() => setConfirmSave(false)}
        onConfirm={handleSave}
        title="Save to evidence vault?"
        message="This result and its details will be saved to your private evidence vault. You can download or delete it later."
        confirmLabel="Save"
      />
    </div>
  )
}
