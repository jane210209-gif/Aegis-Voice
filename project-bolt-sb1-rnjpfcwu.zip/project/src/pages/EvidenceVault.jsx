import { useEffect, useState } from 'react'
import toast from 'react-hot-toast'
import { FolderLock, Download, Trash2, ExternalLink, RefreshCw, FileText, Image as ImageIcon, Video, ShieldAlert, MessageSquareWarning } from 'lucide-react'
import { PageHeader } from '../components/Shared'
import { ErrorState, EmptyState, SkeletonRows } from '../components/StateViews'
import { ConfirmDialog } from '../components/Modal'
import { getEvidence, deleteEvidence } from '../services/evidenceService'
import { ensureArray, formatDate } from '../utils/helpers'

const TYPE_ICON = {
  image: ImageIcon,
  video: Video,
  deepfake: ShieldAlert,
  harassment: MessageSquareWarning,
  alert: ShieldAlert,
  text: FileText,
}

export default function EvidenceVault() {
  const [items, setItems] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [confirmDelete, setConfirmDelete] = useState(null)

  const load = async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await getEvidence()
      setItems(ensureArray(res))
    } catch (err) {
      setError(err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  const handleDelete = async (id) => {
    try {
      await deleteEvidence(id)
      toast.success('Evidence deleted.')
      load()
    } catch {
      toast.error('Could not delete. Please try again.')
    }
  }

  const handleDownload = (item) => {
    const blob = new Blob([JSON.stringify(item, null, 2)], { type: 'application/json' })
    const url = URL.createObjectURL(blob)
    const a = document.createElement('a')
    a.href = url
    a.download = `evidence-${item?.id || formatDate(item?.created_at).replace(/[^a-zA-Z0-9]/g, '')}.json`
    document.body.appendChild(a)
    a.click()
    document.body.removeChild(a)
    URL.revokeObjectURL(url)
    toast.success('Evidence downloaded.')
  }

  return (
    <div>
      <PageHeader
        title="Evidence Vault"
        description="Your saved evidence, kept private. Download or delete items at any time."
        action={<button onClick={load} className="btn-secondary"><RefreshCw className="h-4 w-4" /> Refresh</button>}
      />

      {loading && <SkeletonRows count={4} />}

      {!loading && error && <ErrorState error={error} onRetry={load} />}

      {!loading && !error && items.length === 0 && (
        <EmptyState
          title="No evidence saved yet"
          message="When you analyse content and choose “Save evidence,” it will appear here with timestamps and source details."
          icon={FolderLock}
        />
      )}

      {!loading && !error && items.length > 0 && (
        <div className="space-y-3">
          {items.map((item, i) => {
            const type = String(item?.type || 'text').toLowerCase()
            const Icon = TYPE_ICON[type] || FileText
            return (
              <div key={item?.id || i} className="card p-4">
                <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <div className="flex items-start gap-3">
                    <div className="rounded-xl bg-electric/10 p-2.5">
                      <Icon className="h-5 w-5 text-electric" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-navy-600 dark:text-navy-50">
                        {item?.title || item?.description || 'Evidence item'}
                      </p>
                      <p className="mt-0.5 text-xs text-navy-400 dark:text-navy-200">
                        Type: {type} · Saved: {formatDate(item?.created_at || item?.timestamp)}
                      </p>
                      {item?.source_url && (
                        <a
                          href={item.source_url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="mt-1 flex items-center gap-1 text-xs text-electric hover:underline"
                        >
                          Source <ExternalLink className="h-3 w-3" />
                        </a>
                      )}
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <button onClick={() => handleDownload(item)} className="btn-ghost text-electric" title="Download">
                      <Download className="h-4 w-4" />
                    </button>
                    <button onClick={() => setConfirmDelete(item?.id)} className="btn-ghost text-danger" title="Delete">
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      )}

      <ConfirmDialog
        open={!!confirmDelete}
        onClose={() => setConfirmDelete(null)}
        onConfirm={() => handleDelete(confirmDelete)}
        title="Delete this evidence?"
        message="This action cannot be undone. The evidence item will be permanently removed from your vault."
        confirmLabel="Delete permanently"
        danger
      />
    </div>
  )
}
