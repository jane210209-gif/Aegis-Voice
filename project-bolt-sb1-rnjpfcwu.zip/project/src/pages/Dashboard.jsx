import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import {
  PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, Area, AreaChart,
} from 'recharts'
import {
  Image as ImageIcon, Video, ScanSearch, ShieldAlert, MessageSquareWarning,
  AlertTriangle, Activity, Upload, Bell, TrendingUp,
} from 'lucide-react'
import { PageHeader, StatCard, RiskBadge } from '../components/Shared'
import { ErrorState, EmptyState, SkeletonCard } from '../components/StateViews'
import * as svc from '../services/healthService'
import { getIncidents } from '../services/incidentService'
import { getAlerts } from '../services/alertService'
import { getMedia } from '../services/mediaService'
import { ensureArray, pickNumber, formatDate, classNames } from '../utils/helpers'

const RISK_COLORS = { low: '#10B981', medium: '#F59E0B', high: '#EF4444', unknown: '#647AA0' }

export default function Dashboard() {
  const [stats, setStats] = useState({})
  const [incidents, setIncidents] = useState([])
  const [alerts, setAlerts] = useState([])
  const [activity, setActivity] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)

  useEffect(() => {
    let active = true
    async function load() {
      setLoading(true)
      setError(null)
      try {
        const [media, incidentsData, alertsData, health] = await Promise.allSettled([
          getMedia(),
          getIncidents(),
          getAlerts(),
          svc.getHealth(),
        ])
        if (!active) return

        const mediaArr = media.status === 'fulfilled' ? ensureArray(media.value) : []
        const incidentsArr = incidentsData.status === 'fulfilled' ? ensureArray(incidentsData.value) : []
        const alertsArr = alertsData.status === 'fulfilled' ? ensureArray(alertsData.value) : []

        // Derive stats strictly from API data
        const imagesUploaded = mediaArr.filter((m) => String(m?.type || m?.media_type || '').startsWith('image')).length
        const videosUploaded = mediaArr.filter((m) => String(m?.type || m?.media_type || '').startsWith('video')).length
        const imagesAnalyzed = incidentsArr.filter((i) => i?.type === 'image' || i?.category === 'image').length
        const videosAnalyzed = incidentsArr.filter((i) => i?.type === 'video' || i?.category === 'video').length
        const potentialMatches = incidentsArr.filter((i) => i?.matches || pickNumber(i?.match_count) > 0).length
        const suspectedDeepfakes = incidentsArr.filter((i) =>
          i?.deepfake === true || i?.is_deepfake === true || i?.type === 'deepfake' || i?.category === 'deepfake',
        ).length
        const abusiveComments = incidentsArr.filter((i) =>
          i?.type === 'harassment' || i?.category === 'harassment' || i?.category === 'abusive',
        ).length
        const threateningMessages = incidentsArr.filter((i) =>
          i?.threat === true || i?.is_threat === true || i?.category === 'threat',
        ).length

        setStats({
          uploadedMedia: mediaArr.length,
          imagesAnalyzed,
          videosAnalyzed,
          potentialMatches,
          suspectedDeepfakes,
          abusiveComments,
          threateningMessages,
        })
        setIncidents(incidentsArr)
        setAlerts(alertsArr)

        // Activity timeline from incidents + alerts
        const combined = [
          ...incidentsArr.map((i) => ({ ts: i?.created_at || i?.timestamp, label: i?.title || i?.description || 'Incident', risk: i?.risk || i?.level })),
          ...alertsArr.map((a) => ({ ts: a?.created_at || a?.timestamp, label: a?.message || a?.title || 'Alert', risk: a?.risk || a?.level })),
        ]
          .filter((x) => x.ts)
          .sort((a, b) => new Date(b.ts) - new Date(a.ts))
          .slice(0, 8)
        setActivity(combined)
      } catch (err) {
        if (active) setError(err)
      } finally {
        if (active) setLoading(false)
      }
    }
    load()
    return () => { active = false }
  }, [])

  if (loading) {
    return (
      <div>
        <PageHeader title="Dashboard" description="An overview of your media, analyses, and alerts." />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {Array.from({ length: 7 }).map((_, i) => <SkeletonCard key={i} />)}
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div>
        <PageHeader title="Dashboard" description="An overview of your media, analyses, and alerts." />
        <ErrorState error={error} onRetry={() => window.location.reload()} />
      </div>
    )
  }

  const cards = [
    { label: 'Uploaded media', value: stats.uploadedMedia, icon: ImageIcon, accent: 'electric' },
    { label: 'Images analyzed', value: stats.imagesAnalyzed, icon: ScanSearch, accent: 'cyan' },
    { label: 'Videos analyzed', value: stats.videosAnalyzed, icon: Video, accent: 'cyan' },
    { label: 'Potential matches', value: stats.potentialMatches, icon: ShieldAlert, accent: 'warning' },
    { label: 'Suspected deepfakes', value: stats.suspectedDeepfakes, icon: AlertTriangle, accent: 'danger' },
    { label: 'Abusive comments', value: stats.abusiveComments, icon: MessageSquareWarning, accent: 'danger' },
    { label: 'Threatening messages', value: stats.threateningMessages, icon: AlertTriangle, accent: 'warning' },
  ]

  // Risk distribution from incidents
  const riskBuckets = incidents.reduce((acc, i) => {
    const r = (i?.risk || i?.level || 'unknown').toLowerCase()
    acc[r] = (acc[r] || 0) + 1
    return acc
  }, {})
  const riskData = Object.entries(riskBuckets).map(([name, value]) => ({ name, value }))

  // Platform-wise incidents
  const platformBuckets = incidents.reduce((acc, i) => {
    const p = i?.platform || i?.source || 'unknown'
    acc[p] = (acc[p] || 0) + 1
    return acc
  }, {})
  const platformData = Object.entries(platformBuckets).map(([name, value]) => ({ name, value }))

  // Recent activity sparkline-ish area chart
  const activityChart = activity.slice().reverse().map((a, i) => ({
    name: formatDate(a.ts).split(',')[0],
    count: i + 1,
  }))

  return (
    <div>
      <PageHeader
        title="Dashboard"
        description="An overview of your media, analyses, and alerts. Numbers come from your account only."
        action={<Link to="/media" className="btn-primary"><Upload className="h-4 w-4" /> Upload media</Link>}
      />

      {/* Stat cards */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {cards.map((c) => (
          <StatCard key={c.label} {...c} />
        ))}
      </div>

      {/* Charts */}
      <div className="mt-6 grid gap-6 lg:grid-cols-2">
        {/* Risk distribution */}
        <div className="card p-6">
          <h3 className="flex items-center gap-2 font-semibold text-navy-600 dark:text-navy-50">
            <Activity className="h-4 w-4 text-electric" />
            Risk distribution
          </h3>
          {riskData.length === 0 ? (
            <div className="flex h-64 items-center justify-center text-sm text-navy-300">
              No incidents to chart yet.
            </div>
          ) : (
            <div className="mt-4 h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie data={riskData} dataKey="value" nameKey="name" cx="50%" cy="50%" innerRadius={50} outerRadius={90} paddingAngle={2}>
                    {riskData.map((entry) => (
                      <Cell key={entry.name} fill={RISK_COLORS[entry.name] || RISK_COLORS.unknown} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ background: '#0A1628', border: 'none', borderRadius: 12, color: '#F8FAFC' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
          )}
          {riskData.length > 0 && (
            <div className="mt-2 flex flex-wrap justify-center gap-3">
              {riskData.map((r) => (
                <span key={r.name} className="flex items-center gap-1.5 text-xs text-navy-400 dark:text-navy-200">
                  <span className="h-2.5 w-2.5 rounded-full" style={{ background: RISK_COLORS[r.name] || RISK_COLORS.unknown }} />
                  {r.name} ({r.value})
                </span>
              ))}
            </div>
          )}
        </div>

        {/* Platform-wise incidents */}
        <div className="card p-6">
          <h3 className="flex items-center gap-2 font-semibold text-navy-600 dark:text-navy-50">
            <TrendingUp className="h-4 w-4 text-cyan" />
            Incidents by platform
          </h3>
          {platformData.length === 0 ? (
            <div className="flex h-64 items-center justify-center text-sm text-navy-300">
              No platform data yet.
            </div>
          ) : (
            <div className="mt-4 h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={platformData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="#92A2BD30" />
                  <XAxis dataKey="name" tick={{ fontSize: 12, fill: '#647AA0' }} />
                  <YAxis tick={{ fontSize: 12, fill: '#647AA0' }} allowDecimals={false} />
                  <Tooltip contentStyle={{ background: '#0A1628', border: 'none', borderRadius: 12, color: '#F8FAFC' }} />
                  <Bar dataKey="value" fill="#06B6D4" radius={[8, 8, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>
      </div>

      {/* Recent activity */}
      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        <div className="card p-6 lg:col-span-2">
          <h3 className="flex items-center gap-2 font-semibold text-navy-600 dark:text-navy-50">
            <Activity className="h-4 w-4 text-electric" />
            Recent activity
          </h3>
          {activityChart.length === 0 ? (
            <div className="flex h-48 items-center justify-center text-sm text-navy-300">
              No recent activity.
            </div>
          ) : (
            <div className="mt-4 h-48">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={activityChart}>
                  <defs>
                    <linearGradient id="activityGrad" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="0%" stopColor="#2563EB" stopOpacity={0.3} />
                      <stop offset="100%" stopColor="#2563EB" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <Area type="monotone" dataKey="count" stroke="#2563EB" fill="url(#activityGrad)" strokeWidth={2} />
                  <XAxis dataKey="name" tick={{ fontSize: 11, fill: '#647AA0' }} />
                  <YAxis tick={{ fontSize: 11, fill: '#647AA0' }} allowDecimals={false} />
                  <Tooltip contentStyle={{ background: '#0A1628', border: 'none', borderRadius: 12, color: '#F8FAFC' }} />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          )}
        </div>

        {/* Recent alerts */}
        <div className="card p-6">
          <h3 className="flex items-center gap-2 font-semibold text-navy-600 dark:text-navy-50">
            <Bell className="h-4 w-4 text-warning" />
            Recent alerts
          </h3>
          {alerts.length === 0 ? (
            <div className="mt-4">
              <EmptyState title="No alerts" message="You're all caught up." icon={Bell} />
            </div>
          ) : (
            <ul className="mt-4 space-y-3">
              {alerts.slice(0, 5).map((a, i) => (
                <li key={i} className="flex items-start gap-3 rounded-xl bg-navy-50 p-3 dark:bg-navy-600">
                  <RiskBadge level={a?.risk || a?.level} />
                  <div className="flex-1">
                    <p className="text-sm font-medium text-navy-600 dark:text-navy-50">{a?.message || a?.title || 'Alert'}</p>
                    <p className="text-xs text-navy-300">{formatDate(a?.created_at || a?.timestamp)}</p>
                  </div>
                </li>
              ))}
            </ul>
          )}
          <Link to="/alerts" className="mt-4 block text-center text-sm text-electric hover:underline">
            View all alerts
          </Link>
        </div>
      </div>
    </div>
  )
}
