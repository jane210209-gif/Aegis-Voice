import { Link } from 'react-router-dom'
import { classNames } from '../utils/helpers'

export function StatCard({ label, value, icon: Icon, accent = 'electric', loading }) {
  const accents = {
    electric: 'bg-electric/10 text-electric',
    cyan: 'bg-cyan/10 text-cyan',
    safe: 'bg-safe/10 text-safe',
    warning: 'bg-warning/10 text-warning',
    danger: 'bg-danger/10 text-danger',
  }
  return (
    <div className="card card-hover p-5">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm font-medium text-navy-400 dark:text-navy-200">{label}</p>
          {loading ? (
            <div className="skeleton mt-2 h-8 w-16" />
          ) : (
            <p className="mt-1 text-2xl font-bold text-navy-700 dark:text-navy-50">{value}</p>
          )}
        </div>
        {Icon && (
          <div className={classNames('rounded-xl p-2.5', accents[accent])}>
            <Icon className="h-5 w-5" />
          </div>
        )}
      </div>
    </div>
  )
}

export function RiskBadge({ level }) {
  const l = String(level || '').toLowerCase()
  const map = {
    low: 'bg-safe/15 text-safe',
    medium: 'bg-warning/15 text-warning',
    high: 'bg-danger/15 text-danger',
    critical: 'bg-danger text-white',
  }
  return <span className={classNames('badge', map[l] || 'bg-navy-100 text-navy-500')}>{level || 'unknown'}</span>
}

export function PageHeader({ title, description, action, to, actionLabel }) {
  return (
    <div className="mb-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h1 className="text-2xl font-bold text-navy-700 dark:text-navy-50">{title}</h1>
        {description && <p className="mt-1 text-sm text-navy-400 dark:text-navy-200">{description}</p>}
      </div>
      {action}
      {to && actionLabel && (
        <Link to={to} className="btn-primary">
          {actionLabel}
        </Link>
      )}
    </div>
  )
}
