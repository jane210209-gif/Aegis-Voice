import api from './api'

export async function getSocial() {
  const res = await api.get('/api/social/')
  return res.data
}

export async function connectSocial(platform, payload) {
  const res = await api.post('/api/social/', { platform, action: 'connect', ...payload })
  return res.data
}

export async function disconnectSocial(platform) {
  const res = await api.post('/api/social/', { platform, action: 'disconnect' })
  return res.data
}
