import api from './api'

export async function getHealth() {
  const res = await api.get('/api/health')
  return res.data
}

export async function getAIStatus() {
  const res = await api.get('/api/ai/status')
  return res.data
}
