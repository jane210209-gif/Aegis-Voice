import { NavLink, useNavigate } from 'react-router-dom'
import { useAuth } from '../context/AuthContext'
import {
  LayoutDashboard, Image as ImageIcon, ScanSearch, MessageSquareWarning,
  Share2, Bell, Shield, FolderLock, LifeBuoy, Settings, LogOut, X, ShieldCheck,
} from 'lucide-react'
import { classNames } from '../utils/helpers'

const links = [
  { to: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
  { to: '/media', label: 'Media Upload', icon: ImageIcon },
  { to: '/analysis/image', label: 'Image Misuse', icon: ScanSearch },
  { to: '/analysis/video', label: 'Video Analysis', icon: ScanSearch },
  { to: '/analysis/deepfake', label: 'Deepfake Check', icon: ShieldCheck },
  { to: '/analysis/harassment', label: 'Harassment Text', icon: MessageSquareWarning },
  { to: '/social', label: 'Social Monitoring', icon: Share2 },
  { to: '/alerts', label: 'Alerts', icon: Bell },
  { to: '/evidence', label: 'Evidence Vault', icon: FolderLock },
  { to: '/sos', label: 'SOS & Support', icon: LifeBuoy },
  { to: '/settings', label: 'Settings', icon: Settings },
]

export function Sidebar({ onNavigate }) {
  const { logout, user } = useAuth()
  const navigate = useNavigate()

  const handleLogout = async () => {
    await logout()
    navigate('/')
  }

  return (
    <aside className="flex h-full w-64 flex-col border-r border-navy-100 bg-white dark:border-navy-500/40 dark:bg-navy-700">
      <div className="flex items-center gap-2 px-5 py-5">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-electric text-white">
          <Shield className="h-5 w-5" />
        </div>
        <span className="text-lg font-bold text-navy-700 dark:text-navy-50">Aegis Voice</span>
      </div>
      <nav className="flex-1 space-y-1 overflow-y-auto px-3 py-2">
        {links.map((l) => {
          const Icon = l.icon
          return (
            <NavLink
              key={l.to}
              to={l.to}
              onClick={onNavigate}
              className={({ isActive }) => classNames(
                'flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors',
                isActive
                  ? 'bg-electric/10 text-electric'
                  : 'text-navy-400 hover:bg-navy-50 hover:text-navy-600 dark:text-navy-100 dark:hover:bg-navy-600',
              )}
            >
              <Icon className="h-4 w-4 shrink-0" />
              <span className="truncate">{l.label}</span>
            </NavLink>
          )
        })}
      </nav>
      <div className="border-t border-navy-100 p-3 dark:border-navy-500/40">
        {user?.name && (
          <div className="mb-2 px-3 text-sm text-navy-400 dark:text-navy-200">
            Signed in as <span className="font-medium text-navy-600 dark:text-navy-50">{user.name}</span>
          </div>
        )}
        <button onClick={handleLogout} className="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium text-danger hover:bg-danger/10">
          <LogOut className="h-4 w-4" />
          Log out
        </button>
      </div>
    </aside>
  )
}

export function BottomNav() {
  return (
    <nav className="fixed bottom-0 left-0 right-0 z-40 flex items-center justify-around border-t border-navy-100 bg-white px-1 py-2 dark:border-navy-500/40 dark:bg-navy-700 lg:hidden">
      {links.slice(0, 6).map((l) => {
        const Icon = l.icon
        return (
          <NavLink
            key={l.to}
            to={l.to}
            className={({ isActive }) => classNames(
              'flex flex-col items-center gap-0.5 rounded-lg px-2 py-1.5 text-xs',
              isActive ? 'text-electric' : 'text-navy-400 dark:text-navy-100',
            )}
          >
            <Icon className="h-5 w-5" />
            <span className="max-w-[64px] truncate">{l.label.split(' ')[0]}</span>
          </NavLink>
        )
      })}
    </nav>
  )
}

export function MobileDrawer({ open, onClose }) {
  if (!open) return null
  return (
    <div className="fixed inset-0 z-50 lg:hidden">
      <div className="absolute inset-0 bg-navy-900/60 backdrop-blur-sm" onClick={onClose} />
      <div className="absolute left-0 top-0 h-full">
        <div className="relative h-full">
          <button onClick={onClose} className="absolute right-3 top-3 z-10 rounded-lg p-1.5 text-navy-300 hover:bg-navy-50 dark:hover:bg-navy-600">
            <X className="h-5 w-5" />
          </button>
          <Sidebar onNavigate={onClose} />
        </div>
      </div>
    </div>
  )
}
