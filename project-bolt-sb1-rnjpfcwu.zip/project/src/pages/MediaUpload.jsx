import { useState } from 'react'
import { Link } from 'react-router-dom'
import toast from 'react-hot-toast'
import { Upload, Shield, Lock, FileImage, FileVideo, CheckCircle2 } from 'lucide-react'
import { PageHeader } from '../components/Shared'
import { Dropzone } from '../components/Dropzone'
import { uploadMedia } from '../services/mediaService'
import { formatBytes } from '../utils/helpers'

export default function MediaUpload() {
  const [selectedFile, setSelectedFile] = useState(null)
  const [acceptType, setAcceptType] = useState('image')
  const [progress, setProgress] = useState(0)
  const [uploading, setUploading] = useState(false)
  const [result, setResult] = useState(null)
  const [consented, setConsented] = useState(false)
  const [error, setError] = useState(null)

  const handleUpload = async () => {
    if (!selectedFile) return
    if (!consented) {
      toast.error('Please review the privacy notice before uploading.')
      return
    }
    setUploading(true)
    setError(null)
    setProgress(0)
    try {
      const res = await uploadMedia(selectedFile, setProgress)
      setResult(res)
      toast.success('Upload complete. You can now analyse this file.')
    } catch (err) {
      const msg = err?.response?.data?.detail || err?.response?.data?.message || 'Upload failed. Please try again.'
      setError(msg)
      toast.error(msg)
    } finally {
      setUploading(false)
    }
  }

  return (
    <div>
      <PageHeader
        title="Media Upload"
        description="Upload an image or video for analysis. We only process files you submit — never your private chats."
      />

      {/* Privacy notice */}
      <div className="card mb-6 flex items-start gap-4 p-5">
        <div className="rounded-xl bg-safe/10 p-3">
          <Lock className="h-5 w-5 text-safe" />
        </div>
        <div className="flex-1">
          <h3 className="font-semibold text-navy-600 dark:text-navy-50">Before you upload</h3>
          <p className="mt-1 text-sm text-navy-400 dark:text-navy-200">
            Aegis Voice does not scan WhatsApp, Signal, or any private messaging app. Your file is processed only for the
            analysis you request. Nothing is shared with third parties without your explicit action.
          </p>
          <label className="mt-3 flex cursor-pointer items-center gap-2 text-sm font-medium text-navy-600 dark:text-navy-50">
            <input
              type="checkbox"
              checked={consented}
              onChange={(e) => setConsented(e.target.checked)}
              className="h-4 w-4 rounded border-navy-200 text-electric focus:ring-electric dark:border-navy-500 dark:bg-navy-700"
            />
            I understand and consent to this file being analysed.
          </label>
        </div>
      </div>

      {/* Type toggle */}
      <div className="mb-6 flex gap-3">
        <button
          onClick={() => { setAcceptType('image'); setSelectedFile(null) }}
          className={`btn ${acceptType === 'image' ? 'bg-electric text-white' : 'btn-secondary'}`}
        >
          <FileImage className="h-4 w-4" /> Image
        </button>
        <button
          onClick={() => { setAcceptType('video'); setSelectedFile(null) }}
          className={`btn ${acceptType === 'video' ? 'bg-electric text-white' : 'btn-secondary'}`}
        >
          <FileVideo className="h-4 w-4" /> Video
        </button>
      </div>

      {/* Dropzone */}
      <div className="card p-6">
        <Dropzone accept={acceptType} onFile={setSelectedFile} disabled={uploading} />

        {selectedFile && (
          <div className="mt-4 flex items-center justify-between rounded-xl bg-navy-50 p-4 dark:bg-navy-600">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-electric/10 p-2">
                {acceptType === 'video' ? <FileVideo className="h-5 w-5 text-electric" /> : <FileImage className="h-5 w-5 text-electric" />}
              </div>
              <div>
                <p className="text-sm font-medium text-navy-600 dark:text-navy-50">{selectedFile.name}</p>
                <p className="text-xs text-navy-400 dark:text-navy-200">{formatBytes(selectedFile.size)}</p>
              </div>
            </div>
            {!uploading && (
              <button onClick={() => setSelectedFile(null)} className="text-sm text-danger hover:underline">
                Remove
              </button>
            )}
          </div>
        )}

        {/* Progress */}
        {uploading && (
          <div className="mt-4">
            <div className="mb-1 flex justify-between text-sm text-navy-400 dark:text-navy-200">
              <span>Uploading…</span>
              <span>{progress}%</span>
            </div>
            <div className="h-2 overflow-hidden rounded-full bg-navy-100 dark:bg-navy-500">
              <div className="h-full rounded-full bg-electric transition-all duration-300" style={{ width: `${progress}%` }} />
            </div>
          </div>
        )}

        {/* Error */}
        {error && (
          <div className="mt-4 rounded-xl bg-danger/10 p-4 text-sm text-danger">
            {error}
          </div>
        )}

        {/* Success */}
        {result && (
          <div className="mt-4 rounded-xl bg-safe/10 p-4">
            <div className="flex items-center gap-2 text-sm font-medium text-safe">
              <CheckCircle2 className="h-4 w-4" />
              Upload complete
            </div>
            <p className="mt-1 text-sm text-navy-400 dark:text-navy-200">
              Your file has been stored. You can now run an analysis.
            </p>
            <div className="mt-3 flex gap-3">
              <Link to={acceptType === 'video' ? '/analysis/video' : '/analysis/image'} className="btn-primary">
                <Shield className="h-4 w-4" /> Analyse now
              </Link>
              <Link to="/analysis/deepfake" className="btn-secondary">
                <Shield className="h-4 w-4" /> Check for deepfake
              </Link>
            </div>
          </div>
        )}

        {/* Upload button */}
        <button
          onClick={handleUpload}
          disabled={!selectedFile || uploading || !consented}
          className="btn-primary mt-6 w-full"
        >
          <Upload className="h-4 w-4" />
          {uploading ? 'Uploading…' : 'Upload file'}
        </button>
      </div>
    </div>
  )
}
