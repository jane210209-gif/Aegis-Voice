import { useState } from 'react'
import { Link, useNavigate, useLocation } from 'react-router-dom'
import toast from 'react-hot-toast'
import { Shield, Eye, EyeOff, LifeBuoy, Mail } from 'lucide-react'
import { useAuth } from '../context/AuthContext'

export default function Login() {
  const { login, loading } = useAuth()
  const navigate = useNavigate()
  const location = useLocation()
  const [form, setForm] = useState({ email: '', password: '' })
  const [showPass, setShowPass] = useState(false)
  const [errors, setErrors] = useState({})
  const [showForgot, setShowForgot] = useState(false)

  const validate = () => {
    const e = {}
    if (!form.email.trim()) e.email = 'Email is required.'
    else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) e.email = 'Enter a valid email address.'
    if (!form.password) e.password = 'Password is required.'
    setErrors(e)
    return Object.keys(e).length === 0
  }

  const handleSubmit = async (ev) => {
    ev.preventDefault()
    if (!validate()) return
    try {
      await login({ email: form.email, password: form.password })
      toast.success('Welcome back.')
      const dest = location.state?.from?.pathname || '/dashboard'
      navigate(dest)
    } catch (err) {
      const msg = err?.response?.data?.detail || err?.response?.data?.message || 'Could not log you in. Check your details and try again.'
      toast.error(msg)
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-bglight px-4 py-8 dark:bg-navy-800">
      <div className="w-full max-w-md">
        <Link to="/" className="mb-8 flex items-center justify-center gap-2">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-electric text-white">
            <Shield className="h-5 w-5" />
          </div>
          <span className="text-lg font-bold text-navy-700 dark:text-navy-50">Aegis Voice</span>
        </Link>

        {showForgot ? (
          <div className="card p-8">
            <div className="mb-4 flex items-center justify-center">
              <div className="rounded-full bg-safe/10 p-3">
                <LifeBuoy className="h-6 w-6 text-safe" />
              </div>
            </div>
            <h1 className="text-center text-2xl font-bold text-navy-700 dark:text-navy-50">Forgot your password?</h1>
            <p className="mt-3 text-center text-sm text-navy-400 dark:text-navy-200">
              Password reset isn't available yet. Please contact support and we'll help you regain access to your account safely.
            </p>
            <Link to="/sos" className="btn-secondary mt-6 w-full">
              <LifeBuoy className="h-4 w-4" />
              Contact support
            </Link>
            <button onClick={() => setShowForgot(false)} className="mt-4 w-full text-center text-sm text-electric hover:underline">
              Back to login
            </button>
          </div>
        ) : (
          <div className="card p-8">
            <h1 className="text-2xl font-bold text-navy-700 dark:text-navy-50">Welcome back</h1>
            <p className="mt-2 text-sm text-navy-400 dark:text-navy-200">Log in to your Aegis Voice account.</p>

            <form onSubmit={handleSubmit} className="mt-6 space-y-4">
              <div>
                <label className="label" htmlFor="email">Email</label>
                <input
                  id="email"
                  type="email"
                  className="input"
                  value={form.email}
                  onChange={(e) => setForm({ ...form, email: e.target.value })}
                  placeholder="you@example.com"
                  autoComplete="email"
                />
                {errors.email && <p className="mt-1 text-xs text-danger">{errors.email}</p>}
              </div>

              <div>
                <label className="label" htmlFor="password">Password</label>
                <div className="relative">
                  <input
                    id="password"
                    type={showPass ? 'text' : 'password'}
                    className="input pr-10"
                    value={form.password}
                    onChange={(e) => setForm({ ...form, password: e.target.value })}
                    placeholder="Your password"
                    autoComplete="current-password"
                  />
                  <button type="button" onClick={() => setShowPass(!showPass)} className="absolute right-3 top-1/2 -translate-y-1/2 text-navy-300 hover:text-navy-500">
                    {showPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
                {errors.password && <p className="mt-1 text-xs text-danger">{errors.password}</p>}
              </div>

              <button type="button" onClick={() => setShowForgot(true)} className="flex items-center gap-1 text-sm text-electric hover:underline">
                <Mail className="h-3.5 w-3.5" />
                Forgot your password?
              </button>

              <button type="submit" disabled={loading} className="btn-primary w-full">
                {loading ? 'Logging in…' : 'Log in'}
              </button>
            </form>

            <p className="mt-6 text-center text-sm text-navy-400 dark:text-navy-200">
              Don't have an account?{' '}
              <Link to="/register" className="font-medium text-electric hover:underline">Sign up</Link>
            </p>
          </div>
        )}
      </div>
    </div>
  )
}
