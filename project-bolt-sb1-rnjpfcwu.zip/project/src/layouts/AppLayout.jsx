import { useState } from 'react'
import { Outlet } from 'react-router-dom'
import { Menu, Shield } from 'lucide-react'
import { Sidebar, BottomNav, MobileDrawer } from '../components/Navigation'

export default function AppLayout() {
  const [drawer, setDrawer] = useState(false)

  return (
    <div className="flex min-h-screen bg-bglight dark:bg-navy-800">
      <div className="hidden lg:block">
        <Sidebar />
      </div>

      <div className="flex flex-1 flex-col">
        <header className="sticky top-0 z-30 flex items-center justify-between border-b border-navy-100 bg-white/80 px-4 py-3 backdrop-blur-md dark:border-navy-500/40 dark:bg-navy-700/80 lg:hidden">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-electric text-white">
              <Shield className="h-4 w-4" />
            </div>
            <span className="font-bold text-navy-700 dark:text-navy-50">Aegis Voice</span>
          </div>
          <button onClick={() => setDrawer(true)} className="rounded-lg p-2 text-navy-500 hover:bg-navy-50 dark:hover:bg-navy-600">
            <Menu className="h-5 w-5" />
          </button>
        </header>

        <main className="flex-1 px-4 pb-20 pt-6 lg:px-8 lg:pb-8">
          <div className="mx-auto max-w-6xl">
            <Outlet />
          </div>
        </main>
      </div>

      <MobileDrawer open={drawer} onClose={() => setDrawer(false)} />
      <BottomNav />
    </div>
  )
}
