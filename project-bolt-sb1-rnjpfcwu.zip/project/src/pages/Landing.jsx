import { Link } from 'react-router-dom'
import {
  Shield, ShieldCheck, ScanSearch, MessageSquareWarning, FolderLock, LifeBuoy,
  Lock, Eye, Upload, FileSearch, Archive, HandHeart, ArrowRight, Phone, Globe,
} from 'lucide-react'
import { useAuth } from '../context/AuthContext'

const features = [
  { icon: ScanSearch, title: 'Deepfake Detection', desc: 'Upload an image or video to check if it has been manipulated.' },
  { icon: MessageSquareWarning, title: 'Multilingual Harassment Detection', desc: 'Detect abuse in English, Hindi, Telugu, Tamil, and code-mixed text.' },
  { icon: FolderLock, title: 'Private Evidence Vault', desc: 'Save what matters and download a structured record when you need it.' },
  { icon: LifeBuoy, title: 'Calm Reporting Guidance', desc: 'Jurisdiction-aware steps without pretending to be legal advice.' },
]

const steps = [
  { icon: Upload, title: 'Upload', desc: 'Submit a file or paste text. We only analyse what you give us.' },
  { icon: FileSearch, title: 'Analyse', desc: 'Our models estimate risk and surface what may have been manipulated.' },
  { icon: Archive, title: 'Evidence', desc: 'Save results to your private vault with source details and timestamps.' },
  { icon: HandHeart, title: 'Support', desc: 'Follow calm, clear guidance on reporting and getting help.' },
]

const promises = [
  { icon: Lock, title: 'No Chat Scanning', desc: 'We never scan WhatsApp, Signal, or your private messages. Analysis runs only on files and text you submit.' },
  { icon: Eye, title: 'You Are In Control', desc: 'Nothing is shared with third parties. Evidence download is always your action.' },
  { icon: ShieldCheck, title: 'No Invented Results', desc: 'We label every score as a model estimate, not proof. You can always flag “this looks wrong.”' },
]

const emergency = [
  { label: 'Cyber Crime Helpline (India)', value: '1930' },
  { label: 'Emergency', value: '112' },
  { label: 'StopNCII (remove intimate images)', value: 'stopncii.org' },
]

export default function Landing() {
  const { isAuthenticated } = useAuth()

  return (
    <div className="min-h-screen bg-bglight dark:bg-navy-800">
      <header className="sticky top-0 z-30 border-b border-navy-100 bg-white/80 backdrop-blur-md dark:border-navy-500/40 dark:bg-navy-700/80">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-4 lg:px-8">
          <div className="flex items-center gap-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-electric text-white">
              <Shield className="h-5 w-5" />
            </div>
            <span className="text-lg font-bold text-navy-700 dark:text-navy-50">Aegis Voice</span>
          </div>
          <div className="flex items-center gap-3">
            {isAuthenticated ? (
              <Link to="/dashboard" className="btn-primary">Go to Dashboard</Link>
            ) : (
              <>
                <Link to="/login" className="btn-ghost">Log in</Link>
                <Link to="/register" className="btn-primary">Get started</Link>
              </>
            )}
          </div>
        </div>
      </header>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-electric/5 to-transparent dark:from-electric/10" />
        <div className="relative mx-auto max-w-6xl px-4 py-16 text-center lg:px-8 lg:py-24">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full bg-electric/10 px-4 py-1.5 text-sm font-medium text-electric">
            <Lock className="h-4 w-4" />
            Privacy-first. You submit, we analyse.
          </div>
          <h1 className="mx-auto max-w-3xl text-balance text-4xl font-bold leading-tight text-navy-700 dark:text-navy-50 lg:text-5xl">
            Digital safety tools for victims of deepfakes and online harassment
          </h1>
          <p className="mx-auto mt-6 max-w-2xl text-balance text-lg text-navy-400 dark:text-navy-200">
            Detect manipulated images and videos, identify multilingual abuse, preserve evidence, and get calm guidance — without giving up your privacy.
          </p>
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Link to={isAuthenticated ? '/dashboard' : '/register'} className="btn-primary text-base">
              {isAuthenticated ? 'Open your dashboard' : 'Start protecting yourself'}
              <ArrowRight className="h-4 w-4" />
            </Link>
            <Link to="/sos" className="btn-secondary text-base">
              <LifeBuoy className="h-4 w-4" />
              Get help now
            </Link>
          </div>
          <p className="mt-4 text-xs text-navy-300 dark:text-navy-300">
            Aegis Voice does not scan private chats. Analysis runs only on files and text you submit.
          </p>
        </div>
      </section>

      {/* Problem */}
      <section className="mx-auto max-w-6xl px-4 py-12 lg:px-8">
        <div className="card p-8 lg:p-12">
          <h2 className="text-2xl font-bold text-navy-700 dark:text-navy-50">The problem, in plain words</h2>
          <div className="mt-6 grid gap-6 md:grid-cols-3">
            <div>
              <h3 className="font-semibold text-navy-600 dark:text-navy-50">Deepfakes spread fast</h3>
              <p className="mt-2 text-sm text-navy-400 dark:text-navy-200">
                Non-consensual intimate imagery can be shared before you even know it exists. Detecting manipulation early matters.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-navy-600 dark:text-navy-50">Harassment crosses languages</h3>
              <p className="mt-2 text-sm text-navy-400 dark:text-navy-200">
                Abuse in Hinglish, Tanglish, or Tamil often slips past tools built only for English. You deserve detection that understands you.
              </p>
            </div>
            <div>
              <h3 className="font-semibold text-navy-600 dark:text-navy-50">Evidence is hard to keep</h3>
              <p className="mt-2 text-sm text-navy-400 dark:text-navy-200">
                Screenshots get lost. Posts get deleted. A structured, timestamped record can make a real difference when you report.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="mx-auto max-w-6xl px-4 py-12 lg:px-8">
        <h2 className="text-center text-2xl font-bold text-navy-700 dark:text-navy-50">What Aegis Voice can do</h2>
        <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((f) => {
            const Icon = f.icon
            return (
              <div key={f.title} className="card card-hover p-6">
                <div className="mb-4 inline-flex rounded-xl bg-electric/10 p-3">
                  <Icon className="h-6 w-6 text-electric" />
                </div>
                <h3 className="font-semibold text-navy-600 dark:text-navy-50">{f.title}</h3>
                <p className="mt-2 text-sm text-navy-400 dark:text-navy-200">{f.desc}</p>
              </div>
            )
          })}
        </div>
      </section>

      {/* How it works */}
      <section className="bg-white py-16 dark:bg-navy-700">
        <div className="mx-auto max-w-6xl px-4 lg:px-8">
          <h2 className="text-center text-2xl font-bold text-navy-700 dark:text-navy-50">How it works</h2>
          <div className="mt-10 grid gap-8 md:grid-cols-4">
            {steps.map((s, i) => {
              const Icon = s.icon
              return (
                <div key={s.title} className="text-center">
                  <div className="relative mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-electric/10">
                    <Icon className="h-7 w-7 text-electric" />
                    <span className="absolute -right-1 -top-1 flex h-6 w-6 items-center justify-center rounded-full bg-electric text-xs font-bold text-white">
                      {i + 1}
                    </span>
                  </div>
                  <h3 className="font-semibold text-navy-600 dark:text-navy-50">{s.title}</h3>
                  <p className="mt-2 text-sm text-navy-400 dark:text-navy-200">{s.desc}</p>
                </div>
              )
            })}
          </div>
        </div>
      </section>

      {/* Privacy promises */}
      <section className="mx-auto max-w-6xl px-4 py-12 lg:px-8">
        <h2 className="text-center text-2xl font-bold text-navy-700 dark:text-navy-50">Our privacy promises</h2>
        <div className="mt-8 grid gap-6 md:grid-cols-3">
          {promises.map((p) => {
            const Icon = p.icon
            return (
              <div key={p.title} className="card p-6">
                <div className="mb-4 inline-flex rounded-xl bg-safe/10 p-3">
                  <Icon className="h-6 w-6 text-safe" />
                </div>
                <h3 className="font-semibold text-navy-600 dark:text-navy-50">{p.title}</h3>
                <p className="mt-2 text-sm text-navy-400 dark:text-navy-200">{p.desc}</p>
              </div>
            )
          })}
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-6xl px-4 py-12 lg:px-8">
        <div className="card overflow-hidden bg-gradient-to-br from-navy-700 to-navy-800 p-8 text-center lg:p-12">
          <h2 className="text-2xl font-bold text-white lg:text-3xl">You don't have to face this alone</h2>
          <p className="mx-auto mt-4 max-w-xl text-navy-100">
            Create a free account to start detecting deepfakes, analysing harassment, and building your evidence record.
          </p>
          <div className="mt-8 flex flex-col items-center justify-center gap-3 sm:flex-row">
            <Link to={isAuthenticated ? '/dashboard' : '/register'} className="btn-primary text-base">
              {isAuthenticated ? 'Open dashboard' : 'Create your account'}
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* Footer with emergency resources */}
      <footer className="border-t border-navy-100 bg-white py-12 dark:border-navy-500/40 dark:bg-navy-700">
        <div className="mx-auto max-w-6xl px-4 lg:px-8">
          <div className="grid gap-8 md:grid-cols-2">
            <div>
              <div className="flex items-center gap-2">
                <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-electric text-white">
                  <Shield className="h-4 w-4" />
                </div>
                <span className="font-bold text-navy-700 dark:text-navy-50">Aegis Voice</span>
              </div>
              <p className="mt-3 max-w-xs text-sm text-navy-400 dark:text-navy-200">
                Privacy-first digital safety for victims of AI deepfakes and multilingual online harassment.
              </p>
            </div>
            <div>
              <h3 className="flex items-center gap-2 font-semibold text-navy-600 dark:text-navy-50">
                <LifeBuoy className="h-4 w-4 text-danger" />
                Emergency resources
              </h3>
              <ul className="mt-4 space-y-3">
                {emergency.map((e) => (
                  <li key={e.value} className="flex items-center gap-2 text-sm">
                    <Phone className="h-4 w-4 text-navy-300" />
                    <span className="text-navy-400 dark:text-navy-200">{e.label}:</span>
                    <span className="font-medium text-navy-600 dark:text-navy-50">{e.value}</span>
                  </li>
                ))}
                <li className="flex items-center gap-2 text-sm">
                  <Globe className="h-4 w-4 text-navy-300" />
                  <span className="text-navy-400 dark:text-navy-200">If you are in immediate danger, call your local emergency number.</span>
                </li>
              </ul>
            </div>
          </div>
          <div className="mt-8 border-t border-navy-100 pt-6 text-center text-xs text-navy-300 dark:border-navy-500/40 dark:text-navy-300">
            Aegis Voice provides guidance, not legal advice. Always confirm with local authorities. © {new Date().getFullYear()}
          </div>
        </div>
      </footer>
    </div>
  )
}
