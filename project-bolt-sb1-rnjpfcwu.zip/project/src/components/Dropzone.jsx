import { useState, useRef, useCallback } from 'react'
import { UploadCloud, FileVideo, FileImage, X } from 'lucide-react'
import { classNames } from '../utils/helpers'
import { formatBytes } from '../utils/helpers'

const ACCEPTED_IMAGE = ['image/jpeg', 'image/png', 'image/webp', 'image/gif']
const ACCEPTED_VIDEO = ['video/mp4', 'video/webm', 'video/quicktime']
const MAX_IMAGE = 10 * 1024 * 1024
const MAX_VIDEO = 100 * 1024 * 1024

export function Dropzone({ onFile, accept = 'image', disabled }) {
  const [dragging, setDragging] = useState(false)
  const [error, setError] = useState(null)
  const inputRef = useRef(null)

  const accepted = accept === 'video' ? ACCEPTED_VIDEO : ACCEPTED_IMAGE
  const maxSize = accept === 'video' ? MAX_VIDEO : MAX_IMAGE
  const Icon = accept === 'video' ? FileVideo : FileImage

  const validate = useCallback((file) => {
    if (!accepted.includes(file.type)) {
      return `Unsupported file type. Please upload a ${accept === 'video' ? 'video' : 'image'} file.`
    }
    if (file.size > maxSize) {
      return `File too large (max ${formatBytes(maxSize)}).`
    }
    return null
  }, [accepted, accept, maxSize])

  const handleFile = useCallback((file) => {
    const err = validate(file)
    if (err) { setError(err); return }
    setError(null)
    onFile(file)
  }, [validate, onFile])

  return (
    <div>
      <div
        onDragOver={(e) => { e.preventDefault(); if (!disabled) setDragging(true) }}
        onDragLeave={() => setDragging(false)}
        onDrop={(e) => {
          e.preventDefault()
          setDragging(false)
          if (!disabled && e.dataTransfer.files[0]) handleFile(e.dataTransfer.files[0])
        }}
        onClick={() => !disabled && inputRef.current?.click()}
        className={classNames(
          'flex cursor-pointer flex-col items-center justify-center gap-3 rounded-2xl border-2 border-dashed p-10 text-center transition-colors',
          dragging ? 'border-electric bg-electric/5' : 'border-navy-200 dark:border-navy-500',
          disabled && 'cursor-not-allowed opacity-60',
        )}
      >
        <div className="rounded-full bg-electric/10 p-4">
          {dragging ? <UploadCloud className="h-7 w-7 text-electric" /> : <Icon className="h-7 w-7 text-electric" />}
        </div>
        <div>
          <p className="font-medium text-navy-600 dark:text-navy-50">
            Drag &amp; drop or <span className="text-electric">browse</span>
          </p>
          <p className="mt-1 text-xs text-navy-400 dark:text-navy-200">
            {accept === 'video' ? 'MP4, WebM, MOV up to 100MB' : 'JPEG, PNG, WebP, GIF up to 10MB'}
          </p>
        </div>
        <input
          ref={inputRef}
          type="file"
          accept={accepted.join(',')}
          className="hidden"
          disabled={disabled}
          onChange={(e) => e.target.files[0] && handleFile(e.target.files[0])}
        />
      </div>
      {error && (
        <div className="mt-3 flex items-center gap-2 rounded-xl bg-danger/10 p-3 text-sm text-danger">
          <X className="h-4 w-4 shrink-0" />
          {error}
        </div>
      )}
    </div>
  )
}
