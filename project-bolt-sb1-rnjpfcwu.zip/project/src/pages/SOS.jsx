import { Link } from 'react-router-dom'
import {
  LifeBuoy, Phone, Globe, Shield, FileText, AlertTriangle,
  MapPin, MessageCircle, ExternalLink, Info, FolderLock,
} from 'lucide-react'
import { PageHeader } from '../components/Shared'

const helplines = [
  { label: 'Cyber Crime Helpline (India)', value: '1930', note: 'For cybercrime complaints including non-consensual intimate imagery' },
  { label: 'Emergency number', value: '112', note: 'If you are in immediate danger' },
  { label: 'National Commission for Women (India)', value: '7827170170', note: 'Complaints about online harassment of women' },
]

const reportLinks = [
  { platform: 'Instagram', url: 'https://help.instagram.com/192435014247952', desc: 'Report impersonation or intimate image misuse' },
  { platform: 'Facebook', url: 'https://www.facebook.com/help/181211759950160', desc: 'Report non-consensual intimate images' },
  { platform: 'YouTube', url: 'https://support.google.com/youtube/answer/2802016', desc: 'Report harassment or privacy violations' },
  { platform: 'X (Twitter)', url: 'https://help.twitter.com/en/safety-and-security/privacy-violation-policy', desc: 'Report private information or intimate media' },
  { platform: 'Reddit', url: 'https://www.reddit.com/report', desc: 'Report non-consensual intimate media' },
  { platform: 'StopNCII', url: 'https://stopncii.org', desc: 'Free service to help remove intimate images from participating platforms' },
]

const preserveSteps = [
  'Take screenshots of the post, message, or profile — include the URL and timestamp.',
  'Do not delete messages or accounts — they are your evidence.',
  'Record usernames, handles, and any profile details of the person responsible.',
  'Save the original files (images, videos) exactly as you received them.',
  'Download a structured evidence record from your Evidence Vault.',
]

const reportSteps = [
  'Report the content directly on the platform where it was posted (see links below).',
  'File a complaint with your national cyber crime authority (e.g. cybercrime.gov.in in India).',
  'If you are in India, call 1930 or visit cybercrime.gov.in to file an online complaint.',
  'If you feel unsafe, contact your local police or call your emergency number.',
  'Keep all complaint reference numbers — they help when following up.',
]

export default function SOS() {
  return (
    <div>
      <PageHeader
        title="SOS & Support"
        description="Calm, clear guidance for reporting and getting help. You are not alone."
      />

      {/* Calm banner */}
      <div className="card mb-6 flex items-start gap-4 bg-gradient-to-br from-safe/10 to-cyan/5 p-6 dark:from-safe/15 dark:to-cyan/10">
        <div className="rounded-xl bg-safe/15 p-3">
          <Shield className="h-6 w-6 text-safe" />
        </div>
        <div>
          <h2 className="text-lg font-semibold text-navy-700 dark:text-navy-50">Take a breath. You have options.</h2>
          <p className="mt-1 text-sm text-navy-400 dark:text-navy-200">
            If you've found content that scares or hurts you, the steps below can help. There is no rush — do what feels right.
            If this was a false alarm, that's okay too. You don't need to justify checking.
          </p>
        </div>
      </div>

      {/* Emergency contacts */}
      <div className="card mb-6 p-6">
        <h3 className="flex items-center gap-2 font-semibold text-navy-600 dark:text-navy-50">
          <Phone className="h-5 w-5 text-danger" />
          Emergency helplines
        </h3>
        <div className="mt-4 grid gap-4 sm:grid-cols-3">
          {helplines.map((h) => (
            <div key={h.value} className="rounded-xl bg-navy-50 p-4 dark:bg-navy-600">
              <p className="text-2xl font-bold text-navy-700 dark:text-navy-50">{h.value}</p>
              <p className="mt-1 text-sm font-medium text-navy-600 dark:text-navy-50">{h.label}</p>
              <p className="mt-1 text-xs text-navy-400 dark:text-navy-200">{h.note}</p>
            </div>
          ))}
        </div>
        <div className="mt-4 flex items-start gap-2 rounded-xl bg-navy-50 p-3 text-xs text-navy-400 dark:bg-navy-600 dark:text-navy-200">
          <Info className="h-4 w-4 shrink-0" />
          <span>Aegis Voice does not automatically share your location. If you need urgent physical help, call your local emergency number directly.</span>
        </div>
      </div>

      {/* How to preserve evidence */}
      <div className="card mb-6 p-6">
        <h3 className="flex items-center gap-2 font-semibold text-navy-600 dark:text-navy-50">
          <FileText className="h-5 w-5 text-electric" />
          How to preserve evidence
        </h3>
        <ol className="mt-4 space-y-3">
          {preserveSteps.map((step, i) => (
            <li key={i} className="flex items-start gap-3">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-electric/10 text-xs font-bold text-electric">
                {i + 1}
              </span>
              <p className="text-sm text-navy-400 dark:text-navy-200">{step}</p>
            </li>
          ))}
        </ol>
        <Link to="/evidence" className="btn-primary mt-5">
          <FolderLock className="h-4 w-4" /> Go to evidence vault
        </Link>
      </div>

      {/* How to report cybercrime */}
      <div className="card mb-6 p-6">
        <h3 className="flex items-center gap-2 font-semibold text-navy-600 dark:text-navy-50">
          <AlertTriangle className="h-5 w-5 text-warning" />
          How to report cybercrime
        </h3>
        <ol className="mt-4 space-y-3">
          {reportSteps.map((step, i) => (
            <li key={i} className="flex items-start gap-3">
              <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-warning/10 text-xs font-bold text-warning">
                {i + 1}
              </span>
              <p className="text-sm text-navy-400 dark:text-navy-200">{step}</p>
            </li>
          ))}
        </ol>
        <div className="mt-4 flex items-start gap-2 rounded-xl bg-warning/10 p-3 text-xs text-warning">
          <Info className="h-4 w-4 shrink-0" />
          <span>This is general guidance, not legal advice. Laws vary by country and region — please confirm with local authorities.</span>
        </div>
      </div>

      {/* Platform report links */}
      <div className="card p-6">
        <h3 className="flex items-center gap-2 font-semibold text-navy-600 dark:text-navy-50">
          <Globe className="h-5 w-5 text-cyan" />
          Report on each platform
        </h3>
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          {reportLinks.map((r) => (
            <a
              key={r.platform}
              href={r.url}
              target="_blank"
              rel="noopener noreferrer"
              className="group flex items-center justify-between rounded-xl border border-navy-100 p-4 transition-colors hover:border-electric hover:bg-electric/5 dark:border-navy-500"
            >
              <div>
                <p className="text-sm font-medium text-navy-600 dark:text-navy-50">{r.platform}</p>
                <p className="mt-1 text-xs text-navy-400 dark:text-navy-200">{r.desc}</p>
              </div>
              <ExternalLink className="h-4 w-4 text-navy-300 transition-colors group-hover:text-electric" />
            </a>
          ))}
        </div>
      </div>

      {/* Location note */}
      <div className="card mt-6 flex items-start gap-4 p-5">
        <div className="rounded-xl bg-navy-50 p-3 dark:bg-navy-600">
          <MapPin className="h-5 w-5 text-navy-400" />
        </div>
        <div>
          <h3 className="font-semibold text-navy-600 dark:text-navy-50">About your location</h3>
          <p className="mt-1 text-sm text-navy-400 dark:text-navy-200">
            Aegis Voice does not request or share your GPS location. If you need local emergency services, call your emergency number directly.
          </p>
        </div>
      </div>
    </div>
  )
}
