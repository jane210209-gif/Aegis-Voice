import { useEffect, useState } from 'react'
import toast from 'react-hot-toast'
import {
  User, Lock, Share2, Shield, Palette, Trash2, Sun, Moon, Monitor, Eye, EyeOff,
} from 'lucide-react'
import { PageHeader } from '../components/Shared'
import { ErrorState, SkeletonCard } from '../components/StateViews'
import { ConfirmDialog } from '../components/Modal'
import { useTheme } from '../context/ThemeContext'
import { useAuth } from '../context/AuthContext'
import { getProfile, patchProfile } from '../services/profileService'
import { getSocial } from '../services/socialService'
import { ensureArray, classNames } from '../utils/helpers'

const THEME_OPTIONS = [
  { value: 'light', label: 'Light', icon: Sun },
  { value: 'dark', label: 'Dark', icon: Moon },
  { value: 'system', label: 'System', icon: Monitor },
]

export default function Settings() {
  const { theme, setTheme } = useTheme()
  const { user, logout } = useAuth()
  const [profile, setProfile] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [socialAccounts, setSocialAccounts] = useState([])
  const [savingProfile, setSavingProfile] = useState(false)
  const [confirmDelete, setConfirmDelete] = useState(false)
  const [deleteConfirmText, setDeleteConfirmText] = useState('')

  // Profile form
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')

  // Password form
  const [passwords, setPasswords] = useState({ current: '', next: '', confirm: '' })
  const [showPass, setShowPass] = useState(false)
  const [savingPassword, setSavingPassword] = useState(false)

  // Privacy toggles
  const [privacy, setPrivacy] = useState({
    analysis_storage: true,
    auto_save_evidence: false,
    share_analytics: false,
  })

  // Consent
  const [consent, setConsent] = useState(true)

  const load = async () => {
    setLoading(true)
    setError(null)
    try {
      const [profileData, socialData] = await Promise.allSettled([getProfile(), getSocial()])
      if (profileData.status === 'fulfilled') {
        const p = profileData.value
        setProfile(p)
        setName(p?.name || user?.name || '')
        setEmail(p?.email || user?.email || '')
        setPrivacy({
          analysis_storage: p?.analysis_storage ?? true,
          auto_save_evidence: p?.auto_save_evidence ?? false,
          share_analytics: p?.share_analytics ?? false,
        })
        setConsent(p?.consent ?? true)
      }
      if (socialData.status === 'fulfilled') {
        setSocialAccounts(ensureArray(socialData.value).filter((s) => s?.connected || s?.status === 'connected'))
      }
    } catch (err) {
      setError(err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  const handleSaveProfile = async () => {
    setSavingProfile(true)
    try {
      await patchProfile({ name, email })
      toast.success('Profile updated.')
    } catch (err) {
      toast.error(err?.response?.data?.detail || 'Could not update profile.')
    } finally {
      setSavingProfile(false)
    }
  }

  const handleSavePassword = async () => {
    if (!passwords.next) { toast.error('Enter a new password.'); return }
    if (passwords.next.length < 8) { toast.error('Password must be at least 8 characters.'); return }
    if (passwords.next !== passwords.confirm) { toast.error('Passwords do not match.'); return }
    setSavingPassword(true)
    try {
      await patchProfile({
        current_password: passwords.current,
        new_password: passwords.next,
      })
      toast.success('Password updated.')
      setPasswords({ current: '', next: '', confirm: '' })
    } catch (err) {
      toast.error(err?.response?.data?.detail || 'Could not update password.')
    } finally {
      setSavingPassword(false)
    }
  }

  const handleSavePrivacy = async () => {
    try {
      await patchProfile({ ...privacy, consent })
      toast.success('Privacy settings saved.')
    } catch {
      toast.error('Could not save privacy settings.')
    }
  }

  const handleDeleteAccount = async () => {
    try {
      await patchProfile({ delete_account: true })
      toast.success('Account deletion requested.')
      await logout()
      window.location.href = '/'
    } catch {
      toast.error('Could not delete account. Please contact support.')
    }
  }

  if (loading) {
    return (
      <div>
        <PageHeader title="Settings" description="Manage your profile, privacy, and connected accounts." />
        <div className="grid gap-4 sm:grid-cols-2">
          {Array.from({ length: 4 }).map((_, i) => <SkeletonCard key={i} />)}
        </div>
      </div>
    )
  }

  if (error) {
    return (
      <div>
        <PageHeader title="Settings" description="Manage your profile, privacy, and connected accounts." />
        <ErrorState error={error} onRetry={load} />
      </div>
    )
  }

  return (
    <div>
      <PageHeader title="Settings" description="Manage your profile, privacy, and connected accounts." />

      <div className="space-y-6">
        {/* Profile */}
        <div className="card p-6">
          <h3 className="flex items-center gap-2 font-semibold text-navy-600 dark:text-navy-50">
            <User className="h-5 w-5 text-electric" />
            Profile
          </h3>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <div>
              <label className="label" htmlFor="name">Name</label>
              <input id="name" className="input" value={name} onChange={(e) => setName(e.target.value)} />
            </div>
            <div>
              <label className="label" htmlFor="email">Email</label>
              <input id="email" type="email" className="input" value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>
          </div>
          <button onClick={handleSaveProfile} disabled={savingProfile} className="btn-primary mt-4">
            {savingProfile ? 'Saving…' : 'Save profile'}
          </button>
        </div>

        {/* Password */}
        <div className="card p-6">
          <h3 className="flex items-center gap-2 font-semibold text-navy-600 dark:text-navy-50">
            <Lock className="h-5 w-5 text-electric" />
            Change password
          </h3>
          <div className="mt-4 grid gap-4 sm:grid-cols-3">
            <div>
              <label className="label" htmlFor="current">Current</label>
              <input
                id="current"
                type={showPass ? 'text' : 'password'}
                className="input"
                value={passwords.current}
                onChange={(e) => setPasswords({ ...passwords, current: e.target.value })}
                placeholder="••••••••"
                autoComplete="current-password"
              />
            </div>
            <div>
              <label className="label" htmlFor="next">New</label>
              <input
                id="next"
                type={showPass ? 'text' : 'password'}
                className="input"
                value={passwords.next}
                onChange={(e) => setPasswords({ ...passwords, next: e.target.value })}
                placeholder="At least 8 characters"
                autoComplete="new-password"
              />
            </div>
            <div>
              <label className="label" htmlFor="confirm">Confirm</label>
              <input
                id="confirm"
                type={showPass ? 'text' : 'password'}
                className="input"
                value={passwords.confirm}
                onChange={(e) => setPasswords({ ...passwords, confirm: e.target.value })}
                placeholder="Re-enter"
                autoComplete="new-password"
              />
            </div>
          </div>
          <div className="mt-3 flex items-center gap-3">
            <button onClick={() => setShowPass(!showPass)} className="flex items-center gap-1 text-sm text-navy-400 hover:text-navy-600 dark:hover:text-navy-50">
              {showPass ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
              {showPass ? 'Hide' : 'Show'} passwords
            </button>
            <button onClick={handleSavePassword} disabled={savingPassword} className="btn-primary">
              {savingPassword ? 'Updating…' : 'Update password'}
            </button>
          </div>
        </div>

        {/* Connected accounts */}
        <div className="card p-6">
          <h3 className="flex items-center gap-2 font-semibold text-navy-600 dark:text-navy-50">
            <Share2 className="h-5 w-5 text-electric" />
            Connected accounts
          </h3>
          {socialAccounts.length === 0 ? (
            <p className="mt-4 text-sm text-navy-400 dark:text-navy-200">
              No accounts connected. Visit Social Monitoring to connect a platform.
            </p>
          ) : (
            <ul className="mt-4 space-y-3">
              {socialAccounts.map((s, i) => (
                <li key={i} className="flex items-center justify-between rounded-xl bg-navy-50 p-4 dark:bg-navy-600">
                  <span className="text-sm font-medium text-navy-600 dark:text-navy-50">{s?.platform || s?.name}</span>
                  <span className="badge bg-safe/15 text-safe">Connected</span>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Privacy & consent */}
        <div className="card p-6">
          <h3 className="flex items-center gap-2 font-semibold text-navy-600 dark:text-navy-50">
            <Shield className="h-5 w-5 text-safe" />
            Privacy & consent
          </h3>
          <div className="mt-4 space-y-4">
            <Toggle
              label="Store analysis results"
              desc="Keep your analysis results in your account so you can review them later."
              checked={privacy.analysis_storage}
              onChange={(v) => setPrivacy({ ...privacy, analysis_storage: v })}
            />
            <Toggle
              label="Auto-save as evidence"
              desc="Automatically save flagged results to your evidence vault."
              checked={privacy.auto_save_evidence}
              onChange={(v) => setPrivacy({ ...privacy, auto_save_evidence: v })}
            />
            <Toggle
              label="Share anonymous analytics"
              desc="Help improve Aegis Voice by sharing anonymous usage data."
              checked={privacy.share_analytics}
              onChange={(v) => setPrivacy({ ...privacy, share_analytics: v })}
            />
            <Toggle
              label="Consent to analysis"
              desc="I consent to Aegis Voice analysing files and text I submit."
              checked={consent}
              onChange={setConsent}
            />
          </div>
          <button onClick={handleSavePrivacy} className="btn-primary mt-4">Save privacy settings</button>
        </div>

        {/* Theme */}
        <div className="card p-6">
          <h3 className="flex items-center gap-2 font-semibold text-navy-600 dark:text-navy-50">
            <Palette className="h-5 w-5 text-electric" />
            Appearance
          </h3>
          <div className="mt-4 flex gap-3">
            {THEME_OPTIONS.map((t) => {
              const Icon = t.icon
              return (
                <button
                  key={t.value}
                  onClick={() => setTheme(t.value)}
                  className={classNames(
                    'flex items-center gap-2 rounded-xl px-4 py-3 text-sm font-medium transition-colors',
                    theme === t.value
                      ? 'bg-electric text-white'
                      : 'bg-navy-50 text-navy-400 hover:bg-navy-100 dark:bg-navy-600 dark:text-navy-100 dark:hover:bg-navy-500',
                  )}
                >
                  <Icon className="h-4 w-4" />
                  {t.label}
                </button>
              )
            })}
          </div>
        </div>

        {/* Delete account */}
        <div className="card border-2 border-danger/20 p-6">
          <h3 className="flex items-center gap-2 font-semibold text-danger">
            <Trash2 className="h-5 w-5" />
            Delete account
          </h3>
          <p className="mt-2 text-sm text-navy-400 dark:text-navy-200">
            This permanently deletes your account and all associated data. This action cannot be undone.
          </p>
          <button onClick={() => { setConfirmDelete(true); setDeleteConfirmText('') }} className="btn-danger mt-4">
            Delete my account
          </button>
        </div>
      </div>

      <ConfirmDialog
        open={confirmDelete}
        onClose={() => setConfirmDelete(false)}
        onConfirm={handleDeleteAccount}
        title="Delete your account?"
        message="Type DELETE below to confirm. This permanently erases your account and all evidence."
        confirmLabel="Delete permanently"
        danger
      />
    </div>
  )
}

function Toggle({ label, desc, checked, onChange }) {
  return (
    <div className="flex items-start justify-between gap-4 rounded-xl bg-navy-50 p-4 dark:bg-navy-600">
      <div>
        <p className="text-sm font-medium text-navy-600 dark:text-navy-50">{label}</p>
        <p className="mt-1 text-xs text-navy-400 dark:text-navy-200">{desc}</p>
      </div>
      <button
        onClick={() => onChange(!checked)}
        className={classNames(
          'relative h-6 w-11 shrink-0 rounded-full transition-colors',
          checked ? 'bg-electric' : 'bg-navy-200 dark:bg-navy-500',
        )}
      >
        <span
          className={classNames(
            'absolute top-0.5 h-5 w-5 rounded-full bg-white transition-transform',
            checked ? 'translate-x-5' : 'translate-x-0.5',
          )}
        />
      </button>
    </div>
  )
}
