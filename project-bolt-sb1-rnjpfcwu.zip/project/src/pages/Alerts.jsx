import { useEffect, useState, useMemo } from 'react'
import toast from 'react-hot-toast'
import { Bell, Check, X, Save, Filter, RefreshCw, AlertCircle } from 'lucide-react'
import { PageHeader, RiskBadge } from '../components/Shared'
import { ErrorState, EmptyState, SkeletonRows } from '../components/StateViews'
import { getAlerts, patchAlert } from '../services/alertService'
import { saveEvidence } from '../services/evidenceService'
import { ensureArray, formatDate, classNames } from '../utils/helpers'

const RISK_FILTERS = ['all', 'low', 'medium', 'high', 'critical']

export default function Alerts() {
  const [alerts, setAlerts] = useState([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [riskFilter, setRiskFilter] = useState('all')
  const [platformFilter, setPlatformFilter] = useState('all')

  const load = async () => {
    setLoading(true)
    setError(null)
    try {
      const res = await getAlerts()
      setAlerts(ensureArray(res))
    } catch (err) {
      setError(err)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  const platforms = useMemo(() => {
    const set = new Set(alerts.map((a) => a?.platform || a?.source).filter(Boolean))
    return ['all', ...Array.from(set)]
  }, [alerts])

  const filtered = useMemo(() => {
    return alerts.filter((a) => {
      const risk = String(a?.risk || a?.level || '').toLowerCase()
      const platform = a?.platform || a?.source || 'all'
      const riskOk = riskFilter === 'all' || risk === riskFilter
      const platformOk = platformFilter === 'all' || platform === platformFilter
      return riskOk && platformOk
    })
  }, [alerts, riskFilter, platformFilter])

  const handleReview = async (id) => {
    try {
      await patchAlert(id, { status: 'reviewed' })
      toast.success('Alert marked as reviewed.')
      load()
    } catch {
      toast.error('Could not update alert. Please try again.')
    }
  }

  const handleDismiss = async (id) => {
    try {
      await patchAlert(id, { status: 'dismissed' })
      toast.success('Alert dismissed.')
      load()
    } catch {
      toast.error('Could not dismiss alert. Please try again.')
    }
  }

  const handleSaveEvidence = async (alert) => {
    try {
      await saveEvidence({
        type: 'alert',
        source_url: alert?.source_url || '',
        description: alert?.message || alert?.title || 'Alert',
        data: alert,
      })
      toast.success('Saved to your evidence vault.')
    } catch {
      toast.error('Could not save evidence. Please try again.')
    }
  }

  return (
    <div>
      <PageHeader
        title="Alerts"
        description="Recent alerts across your connected platforms."
        action={<button onClick={load} className="btn-secondary"><RefreshCw className="h-4 w-4" /> Refresh</button>}
      />

      {/* Filters */}
      <div className="card mb-6 flex flex-col gap-4 p-4 sm:flex-row sm:items-center">
        <div className="flex items-center gap-2 text-sm font-medium text-navy-500 dark:text-navy-100">
          <Filter className="h-4 w-4" /> Filters
        </div>
        <div className="flex flex-wrap gap-2">
          {RISK_FILTERS.map((r) => (
            <button
              key={r}
              onClick={() => setRiskFilter(r)}
              className={classNames(
                'rounded-lg px-3 py-1.5 text-xs font-medium capitalize transition-colors',
                riskFilter === r
                  ? 'bg-electric text-white'
                  : 'bg-navy-50 text-navy-400 hover:bg-navy-100 dark:bg-navy-600 dark:text-navy-100 dark:hover:bg-navy-500',
              )}
            >
              {r}
            </button>
          ))}
        </div>
        {platforms.length > 1 && (
          <select
            value={platformFilter}
            onChange={(e) => setPlatformFilter(e.target.value)}
            className="input sm:w-48"
          >
            {platforms.map((p) => (
              <option key={p} value={p}>{p === 'all' ? 'All platforms' : p}</option>
            ))}
          </select>
        )}
      </div>

      {loading && <SkeletonRows count={5} />}

      {!loading && error && <ErrorState error={error} onRetry={load} />}

      {!loading && !error && filtered.length === 0 && (
        <EmptyState
          title="No alerts found"
          message={alerts.length === 0 ? "You're all caught up — no alerts right now." : "No alerts match your filters."}
          icon={Bell}
        />
      )}

      {!loading && !error && filtered.length > 0 && (
        <div className="space-y-3">
          {filtered.map((a, i) => (
            <div key={i} className="card p-4">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex items-start gap-3">
                  <div className="rounded-xl bg-warning/10 p-2.5">
                    <AlertCircle className="h-5 w-5 text-warning" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <RiskBadge level={a?.risk || a?.level} />
                      {a?.platform && (
                        <span className="text-xs text-navy-400 dark:text-navy-200">{a.platform}</span>
                      )}
                    </div>
                    <p className="mt-1 text-sm font-medium text-navy-600 dark:text-navy-50">{a?.message || a?.title || 'Alert'}</p>
                    {a?.explanation && <p className="mt-1 text-xs text-navy-400 dark:text-navy-200">{a.explanation}</p>}
                    <p className="mt-1 text-xs text-navy-300">{formatDate(a?.created_at || a?.timestamp)}</p>
                  </div>
                </div>

                <div className="flex gap-2">
                  <button onClick={() => handleReview(a?.id)} className="btn-ghost text-safe" title="Mark as reviewed">
                    <Check className="h-4 w-4" />
                  </button>
                  <button onClick={() => handleSaveEvidence(a)} className="btn-ghost text-electric" title="Save evidence">
                    <Save className="h-4 w-4" />
                  </button>
                  <button onClick={() => handleDismiss(a?.id)} className="btn-ghost text-danger" title="Dismiss">
                    <X className="h-4 w-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
