import { useState } from 'react'
import toast from 'react-hot-toast'
import { ShieldCheck, ShieldAlert, Save, X, Info } from 'lucide-react'
import { PageHeader, RiskBadge } from '../components/Shared'
import { Dropzone } from '../components/Dropzone'
import { ConfirmDialog } from '../components/Modal'
import { analyzeDeepfake } from '../services/analysisService'
import { saveEvidence } from '../services/evidenceService'
import { ensureArray, pickNumber } from '../utils/helpers'

export default function DeepfakeResult() {
  const [file, setFile] = useState(null)
  const [previewUrl, setPreviewUrl] = useState(null)
  const [isVideo, setIsVideo] = useState(false)
  const [analyzing, setAnalyzing] = useState(false)
  const [result, setResult] = useState(null)
  const [error, setError] = useState(null)
  const [confirmSave, setConfirmSave] = useState(false)

  const handleFile = (f) => {
    setFile(f)
    setResult(null)
    setError(null)
    const isVid = f.type.startsWith('video')
    setIsVideo(isVid)
    setPreviewUrl(URL.createObjectURL(f))
  }

  const handleAnalyze = async () => {
    if (!file) return
    setAnalyzing(true)
    setError(null)
    setResult(null)
    try {
      const formData = new FormData()
      formData.append('file', file)
      const res = await analyzeDeepfake(formData)
      setResult(res)
    } catch (err) {
      const status = err?.response?.status
      if (status === 404) {
        setError('This action isn\'t available yet.')
      } else {
        setError(err?.response?.data?.detail || err?.response?.data?.message || 'Analysis failed. Please try again.')
      }
    } finally {
      setAnalyzing(false)
    }
  }

  const handleSave = async () => {
    try {
      await saveEvidence({
        type: 'deepfake',
        description: result?.explanation || 'Deepfake analysis result',
        data: result,
      })
      toast.success('Saved to your evidence vault.')
    } catch {
      toast.error('Could not save evidence. Please try again.')
    }
  }

  const indicators = ensureArray(result?.indicators || result?.artifacts)
  const confidence = pickNumber(result?.confidence ?? result?.score, 0)

  return (
    <div>
      <PageHeader
        title="Deepfake Detection"
        description="Check if an image or video has been AI-manipulated. Results are model estimates — not proof."
      />

      <div className="card p-6">
        <Dropzone accept="image" onFile={handleFile} disabled={analyzing} />
        {previewUrl && (
          <div className="mt-4">
            <p className="label">Preview</p>
            {isVideo ? (
              <video src={previewUrl} controls className="max-h-64 w-full rounded-xl" />
            ) : (
              <img src={previewUrl} alt="Selected" className="max-h-64 rounded-xl object-contain" />
            )}
          </div>
        )}

        <button onClick={handleAnalyze} disabled={!file || analyzing} className="btn-primary mt-6 w-full">
          <ShieldCheck className="h-4 w-4" />
          {analyzing ? 'Checking for manipulation…' : 'Check for deepfake'}
        </button>
      </div>

      {/* Loading */}
      {analyzing && (
        <div className="card mt-6 p-8 text-center">
          <div className="mx-auto h-10 w-10 animate-pulseSoft rounded-full bg-electric/10" />
          <p className="mt-3 text-sm text-navy-400 dark:text-navy-200">
            Scanning for manipulation indicators…
          </p>
        </div>
      )}

      {/* Error */}
      {error && !analyzing && (
        <div className="card mt-6 flex items-start gap-3 p-5">
          <X className="h-5 w-5 shrink-0 text-danger" />
          <p className="text-sm text-danger">{error}</p>
        </div>
      )}

      {/* Result */}
      {result && !analyzing && (
        <div className="mt-6 space-y-6">
          <div className="card p-6">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="flex items-center gap-2 font-semibold text-navy-600 dark:text-navy-50">
                  <ShieldAlert className="h-5 w-5 text-warning" />
                  Deepfake Analysis
                </h3>
                <p className="mt-2 text-sm text-navy-400 dark:text-navy-200">
                  {result?.explanation || result?.message || 'Analysis complete. See details below.'}
                </p>
              </div>
              <RiskBadge level={result?.risk || result?.level} />
            </div>

            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <div className="rounded-xl bg-navy-50 p-4 dark:bg-navy-600">
                <p className="text-xs text-navy-400 dark:text-navy-200">Status</p>
                <p className="mt-1 text-sm font-medium text-navy-700 dark:text-navy-50">
                  {result?.status || (result?.is_deepfake ? 'manipulation detected' : 'no manipulation detected')}
                </p>
              </div>
              <div className="rounded-xl bg-navy-50 p-4 dark:bg-navy-600">
                <p className="text-xs text-navy-400 dark:text-navy-200">Confidence (model estimate)</p>
                <p className="mt-1 text-xl font-bold text-navy-700 dark:text-navy-50">
                  {confidence > 0 ? `${(confidence * 100).toFixed(1)}%` : '—'}
                </p>
              </div>
            </div>

            <div className="mt-4 flex items-start gap-2 rounded-xl bg-warning/10 p-3 text-xs text-warning">
              <Info className="h-4 w-4 shrink-0" />
              <span>This is a model estimate, not proof. Detection is not perfect — please use your own judgment too.</span>
            </div>

            <div className="mt-4">
              <button onClick={() => setConfirmSave(true)} className="btn-primary">
                <Save className="h-4 w-4" /> Save evidence
              </button>
            </div>
          </div>

          {/* Indicators */}
          {indicators.length > 0 && (
            <div className="card p-6">
              <h3 className="font-semibold text-navy-600 dark:text-navy-50">Manipulation indicators</h3>
              <ul className="mt-4 space-y-3">
                {indicators.map((ind, i) => {
                  const label = typeof ind === 'string' ? ind : ind?.label ?? ind?.name ?? ind?.description ?? 'indicator'
                  const score = pickNumber(typeof ind === 'object' ? (ind?.confidence ?? ind?.score) : 0, 0)
                  return (
                    <li key={i} className="flex items-center gap-4 rounded-xl bg-navy-50 p-4 dark:bg-navy-600">
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-warning/10">
                        <ShieldAlert className="h-4 w-4 text-warning" />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-navy-600 dark:text-navy-50">{label}</p>
                        {score > 0 && <p className="text-xs text-navy-400 dark:text-navy-200">Confidence: {(score * 100).toFixed(1)}%</p>}
                      </div>
                    </li>
                  )
                })}
              </ul>
            </div>
          )}
        </div>
      )}

      <ConfirmDialog
        open={confirmSave}
        onClose={() => setConfirmSave(false)}
        onConfirm={handleSave}
        title="Save to evidence vault?"
        message="This deepfake analysis result will be saved to your private evidence vault."
        confirmLabel="Save"
      />
    </div>
  )
}
