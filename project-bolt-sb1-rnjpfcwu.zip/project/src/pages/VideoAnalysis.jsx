import { useState } from 'react'
import toast from 'react-hot-toast'
import { ScanSearch, ShieldAlert, Save, X, Info, PlayCircle, Clock } from 'lucide-react'
import { PageHeader, RiskBadge } from '../components/Shared'
import { Dropzone } from '../components/Dropzone'
import { ConfirmDialog } from '../components/Modal'
import { analyzeVideo } from '../services/analysisService'
import { saveEvidence } from '../services/evidenceService'
import { ensureArray, pickNumber, formatDate } from '../utils/helpers'

export default function VideoAnalysis() {
  const [file, setFile] = useState(null)
  const [previewUrl, setPreviewUrl] = useState(null)
  const [analyzing, setAnalyzing] = useState(false)
  const [result, setResult] = useState(null)
  const [error, setError] = useState(null)
  const [confirmSave, setConfirmSave] = useState(false)

  const handleFile = (f) => {
    setFile(f)
    setResult(null)
    setError(null)
    setPreviewUrl(URL.createObjectURL(f))
  }

  const handleAnalyze = async () => {
    if (!file) return
    setAnalyzing(true)
    setError(null)
    setResult(null)
    try {
      const formData = new FormData()
      formData.append('file', file)
      const res = await analyzeVideo(formData)
      setResult(res)
    } catch (err) {
      const status = err?.response?.status
      if (status === 404) {
        setError('This action isn\'t available yet.')
      } else {
        setError(err?.response?.data?.detail || err?.response?.data?.message || 'Analysis failed. Please try again.')
      }
    } finally {
      setAnalyzing(false)
    }
  }

  const handleSave = async () => {
    try {
      await saveEvidence({
        type: 'video',
        description: result?.explanation || 'Video analysis result',
        data: result,
      })
      toast.success('Saved to your evidence vault.')
    } catch {
      toast.error('Could not save evidence. Please try again.')
    }
  }

  const flagged = ensureArray(result?.flagged_timestamps || result?.timestamps || result?.flags)
  const categories = ensureArray(result?.categories || result?.category)
  const confidence = pickNumber(result?.confidence ?? result?.score, 0)

  return (
    <div>
      <PageHeader
        title="Video Analysis"
        description="Detect manipulation or concerning content in videos you upload. Results are model estimates."
      />

      <div className="card p-6">
        <Dropzone accept="video" onFile={handleFile} disabled={analyzing} />

        {previewUrl && (
          <div className="mt-4">
            <p className="label">Preview</p>
            <video src={previewUrl} controls className="max-h-64 w-full rounded-xl" />
          </div>
        )}

        <button onClick={handleAnalyze} disabled={!file || analyzing} className="btn-primary mt-6 w-full">
          <ScanSearch className="h-4 w-4" />
          {analyzing ? 'Analysing video…' : 'Analyse video'}
        </button>
      </div>

      {/* Loading */}
      {analyzing && (
        <div className="card mt-6 p-8 text-center">
          <div className="mx-auto h-10 w-10 animate-pulseSoft rounded-full bg-electric/10" />
          <p className="mt-3 text-sm text-navy-400 dark:text-navy-200">
            Video analysis can take longer than images. Please wait…
          </p>
        </div>
      )}

      {/* Error */}
      {error && !analyzing && (
        <div className="card mt-6 flex items-start gap-3 p-5">
          <X className="h-5 w-5 shrink-0 text-danger" />
          <p className="text-sm text-danger">{error}</p>
        </div>
      )}

      {/* Result */}
      {result && !analyzing && (
        <div className="mt-6 space-y-6">
          <div className="card p-6">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="flex items-center gap-2 font-semibold text-navy-600 dark:text-navy-50">
                  <ShieldAlert className="h-5 w-5 text-warning" />
                  Analysis Result
                </h3>
                <p className="mt-2 text-sm text-navy-400 dark:text-navy-200">
                  {result?.explanation || result?.message || 'Analysis complete.'}
                </p>
              </div>
              <RiskBadge level={result?.risk || result?.level} />
            </div>

            {/* Status + confidence */}
            <div className="mt-4 grid gap-4 sm:grid-cols-2">
              <div className="rounded-xl bg-navy-50 p-4 dark:bg-navy-600">
                <p className="text-xs text-navy-400 dark:text-navy-200">Status</p>
                <p className="mt-1 text-sm font-medium text-navy-700 dark:text-navy-50">{result?.status || 'completed'}</p>
              </div>
              <div className="rounded-xl bg-navy-50 p-4 dark:bg-navy-600">
                <p className="text-xs text-navy-400 dark:text-navy-200">Confidence (model estimate)</p>
                <p className="mt-1 text-xl font-bold text-navy-700 dark:text-navy-50">
                  {confidence > 0 ? `${(confidence * 100).toFixed(1)}%` : '—'}
                </p>
              </div>
            </div>

            {/* Categories */}
            {categories.length > 0 && (
              <div className="mt-4">
                <p className="label">Categories detected</p>
                <div className="flex flex-wrap gap-2">
                  {categories.map((c, i) => (
                    <span key={i} className="badge bg-navy-100 text-navy-500 dark:bg-navy-500 dark:text-navy-100">
                      {typeof c === 'string' ? c : c?.label || c?.name || 'unknown'}
                    </span>
                  ))}
                </div>
              </div>
            )}

            <div className="mt-4 flex items-start gap-2 rounded-xl bg-warning/10 p-3 text-xs text-warning">
              <Info className="h-4 w-4 shrink-0" />
              <span>This is a model estimate, not proof. Timestamps are approximate and may not be exact.</span>
            </div>

            <div className="mt-4">
              <button onClick={() => setConfirmSave(true)} className="btn-primary">
                <Save className="h-4 w-4" /> Save evidence
              </button>
            </div>
          </div>

          {/* Flagged timestamps */}
          {flagged.length > 0 && (
            <div className="card p-6">
              <h3 className="flex items-center gap-2 font-semibold text-navy-600 dark:text-navy-50">
                <PlayCircle className="h-5 w-5 text-electric" />
                Flagged timestamps
              </h3>
              <ul className="mt-4 space-y-3">
                {flagged.map((f, i) => {
                  const ts = f?.timestamp ?? f?.time ?? f
                  const label = f?.label ?? f?.category ?? f?.description
                  const conf = pickNumber(f?.confidence ?? f?.score, 0)
                  return (
                    <li key={i} className="flex items-center gap-4 rounded-xl bg-navy-50 p-4 dark:bg-navy-600">
                      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-electric/10">
                        <Clock className="h-5 w-5 text-electric" />
                      </div>
                      <div className="flex-1">
                        <p className="text-sm font-medium text-navy-600 dark:text-navy-50">{formatDate(ts)}</p>
                        {label && <p className="text-xs text-navy-400 dark:text-navy-200">{label}</p>}
                      </div>
                      {conf > 0 && <RiskBadge level={conf > 0.7 ? 'high' : conf > 0.4 ? 'medium' : 'low'} />}
                    </li>
                  )
                })}
              </ul>
            </div>
          )}
        </div>
      )}

      <ConfirmDialog
        open={confirmSave}
        onClose={() => setConfirmSave(false)}
        onConfirm={handleSave}
        title="Save to evidence vault?"
        message="This result and its flagged timestamps will be saved to your private evidence vault."
        confirmLabel="Save"
      />
    </div>
  )
}
