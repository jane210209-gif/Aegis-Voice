import api from './api'

export async function getAlerts() {
  const res = await api.get('/api/alerts')
  return res.data
}

export async function patchAlert(id, payload) {
  const res = await api.patch(`/api/alerts`, { id, ...payload })
  return res.data
}
