import api from './api'

export async function getProfile() {
  const res = await api.get('/api/profile')
  return res.data
}

export async function patchProfile(payload) {
  const res = await api.patch('/api/profile', payload)
  return res.data
}
